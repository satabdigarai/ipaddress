# Free IP Geolocation Service

> **Lightning-fast, privacy-focused IP geolocation lookup service with public API**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![API Status](https://img.shields.io/badge/API-Active-brightgreen.svg)](https://ip-address.online/)
[![Response Time](https://img.shields.io/badge/Response%20Time-%3C5ms-brightgreen.svg)](https://ip-address.online/api/health)

## 🌟 Features

- **Lightning Fast**: Sub-millisecond response times with offline MaxMind database
- **Privacy First**: No logging, tracking, or data retention
- **Free & Open**: Completely free public API with no authentication required
- **Comprehensive Data**: Country, state, city, ISP, timezone, and coordinates
- **Production Ready**: Rate limiting, caching, and security headers included
- **IPv4 & IPv6**: Full support for both IP address formats

## 🚀 Quick Start

### Web Interface
Visit **[ip-address.online](https://ip-address.online/)** for the interactive web interface.

### API Usage
```bash
# Get your current IP location
curl https://ip-address.online/api/geo

# Look up any IP address
curl https://ip-address.online/api/geo/8.8.8.8

# Get just your IP address
curl https://ip-address.online/api/myip
```

### Example Response
```json
{
  "ip": "8.8.8.8",
  "countryCode": "US",
  "country": "United States",
  "regionCode": "CA",
  "region": "California",
  "city": "Mountain View",
  "postalCode": "94043",
  "latitude": 37.4056,
  "longitude": -122.0775,
  "timezone": "America/Los_Angeles",
  "isp": "Google LLC",
  "asn": 15169
}
```

## 📚 Code Examples

### Node.js
```javascript
// Using fetch (Node.js 18+)
const response = await fetch('https://ip-address.online/api/geo/8.8.8.8');
const data = await response.json();
console.log(`IP ${data.ip} is located in ${data.city}, ${data.country}`);

// Using axios
const axios = require('axios');
const { data } = await axios.get('https://ip-address.online/api/geo/8.8.8.8');
console.log(data);
```

### Python
```python
import requests

# Look up an IP address
response = requests.get('https://ip-address.online/api/geo/8.8.8.8')
data = response.json()
print(f"IP {data['ip']} is located in {data['city']}, {data['country']}")

# Get your current IP
my_ip = requests.get('https://ip-address.online/api/myip').json()
print(f"Your IP address is: {my_ip['ip']}")
```

### Java
```java
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import com.fasterxml.jackson.databind.ObjectMapper;

HttpClient client = HttpClient.newHttpClient();
HttpRequest request = HttpRequest.newBuilder()
    .uri(URI.create("https://ip-address.online/api/geo/8.8.8.8"))
    .build();

HttpResponse<String> response = client.send(request, 
    HttpResponse.BodyHandlers.ofString());

ObjectMapper mapper = new ObjectMapper();
Map<String, Object> data = mapper.readValue(response.body(), Map.class);
System.out.println("Location: " + data.get("city") + ", " + data.get("country"));
```

### JavaScript/HTML
```html
<!DOCTYPE html>
<html>
<head>
    <title>IP Lookup Example</title>
</head>
<body>
    <div id="result"></div>
    
    <script>
    async function getIPLocation() {
        try {
            const response = await fetch('https://ip-address.online/api/geo');
            const data = await response.json();
            document.getElementById('result').innerHTML = 
                `Your location: ${data.city}, ${data.country}`;
        } catch (error) {
            console.error('Error:', error);
        }
    }
    
    // Get location on page load
    getIPLocation();
    </script>
</body>
</html>
```

### PHP
```php
<?php
// Look up an IP address
$url = 'https://ip-address.online/api/geo/8.8.8.8';
$response = file_get_contents($url);
$data = json_decode($response, true);

echo "IP {$data['ip']} is located in {$data['city']}, {$data['country']}\n";

// Using cURL for more control
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, 'https://ip-address.online/api/geo');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($curl);
curl_close($curl);

$data = json_decode($result, true);
print_r($data);
?>
```

### Ruby
```ruby
require 'net/http'
require 'json'

# Look up an IP address
uri = URI('https://ip-address.online/api/geo/8.8.8.8')
response = Net::HTTP.get_response(uri)
data = JSON.parse(response.body)

puts "IP #{data['ip']} is located in #{data['city']}, #{data['country']}"
```

### Go
```go
package main

import (
    "encoding/json"
    "fmt"
    "net/http"
)

type IPLocation struct {
    IP          string  `json:"ip"`
    Country     string  `json:"country"`
    City        string  `json:"city"`
    Region      string  `json:"region"`
    Latitude    float64 `json:"latitude"`
    Longitude   float64 `json:"longitude"`
}

func main() {
    resp, err := http.Get("https://ip-address.online/api/geo/8.8.8.8")
    if err != nil {
        fmt.Printf("Error: %v\n", err)
        return
    }
    defer resp.Body.Close()

    var location IPLocation
    json.NewDecoder(resp.Body).Decode(&location)
    
    fmt.Printf("IP %s is located in %s, %s\n", 
        location.IP, location.City, location.Country)
}
```

### C#
```csharp
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

public class IPLocation
{
    public string Ip { get; set; }
    public string Country { get; set; }
    public string City { get; set; }
    public string Region { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
}

class Program
{
    private static readonly HttpClient client = new HttpClient();
    
    static async Task Main()
    {
        string url = "https://ip-address.online/api/geo/8.8.8.8";
        HttpResponseMessage response = await client.GetAsync(url);
        string responseBody = await response.Content.ReadAsStringAsync();
        
        IPLocation location = JsonConvert.DeserializeObject<IPLocation>(responseBody);
        Console.WriteLine($"IP {location.Ip} is located in {location.City}, {location.Country}");
    }
}
```

## 🔧 API Endpoints

| Endpoint | Method | Description | Example |
|----------|--------|-------------|---------|
| `/api/geo` | GET | Get location of your current IP | `GET /api/geo` |
| `/api/geo/{ip}` | GET | Get location of specific IP address | `GET /api/geo/8.8.8.8` |
| `/api/myip` | GET | Get your current IP address only | `GET /api/myip` |
| `/api/health` | GET | API health check | `GET /api/health` |
| `/api/stats` | GET | Service statistics | `GET /api/stats` |

## 📊 Response Format

All API endpoints return JSON responses with consistent formatting:

### Successful Response
```json
{
  "ip": "8.8.8.8",
  "countryCode": "US",
  "country": "United States",
  "regionCode": "CA", 
  "region": "California",
  "city": "Mountain View",
  "postalCode": "94043",
  "latitude": 37.4056,
  "longitude": -122.0775,
  "timezone": "America/Los_Angeles",
  "isp": "Google LLC",
  "asn": 15169
}
```

### Error Response
```json
{
  "error": "Invalid IP address format",
  "code": 400
}
```

## ⚡ Rate Limits

- **120 requests per minute** per IP address
- Responses are cached for 15 minutes for optimal performance
- No authentication required

## 🔒 Privacy & Security

- **No Logging**: We don't store or log any IP addresses looked up
- **No Tracking**: No cookies, analytics, or user tracking
- **Offline Processing**: Uses local MaxMind database for lightning-fast responses
- **HTTPS Only**: All API calls are encrypted
- **Security Headers**: Comprehensive security headers implemented

## 🗂️ Data Sources

- **MaxMind GeoLite2**: Industry-standard IP geolocation database
- **Monthly Updates**: Database automatically updated monthly
- **High Accuracy**: 95-99% country-level accuracy, 50-80% city-level accuracy

## ⚙️ Self-Hosting

Want to run your own instance? Check out our [Installation Guide](docs/INSTALLATION.md).

### Quick Deploy
```bash
git clone https://github.com/yourusername/ip-geolocation-service
cd ip-geolocation-service
npm install
npm run build
npm start
```

## 📖 Documentation

- [API Documentation](docs/API.md) - Detailed API reference
- [Installation Guide](docs/INSTALLATION.md) - Self-hosting instructions
- [Configuration](docs/CONFIGURATION.md) - Environment variables and settings
- [Contributing](docs/CONTRIBUTING.md) - How to contribute to the project

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](docs/CONTRIBUTING.md) for details.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Issues**: [GitHub Issues](https://github.com/yourusername/ip-geolocation-service/issues)
- **API Status**: [Service Health](https://ip-address.online/api/health)
- **Documentation**: [Full Documentation](docs/)

## 🏆 Why Choose This Service?

- **Performance**: Sub-millisecond response times
- **Privacy**: No data retention or tracking
- **Reliability**: 99.9% uptime with robust error handling
- **Simplicity**: No API keys or authentication required
- **Comprehensive**: Complete location data including ISP and timezone
- **Standards**: RESTful API design with consistent JSON responses

---

**Made with ❤️ for developers who value speed, privacy, and simplicity.**