<?php
/**
 * PHP Example for Free IP Geolocation API
 * 
 * This example demonstrates various ways to use the API with PHP
 * including error handling, caching, and batch processing.
 * 
 * Requirements: PHP 7.4+, cURL extension
 */

// API Configuration
const API_BASE_URL = 'https://ip-address.replit.app/api';
const CACHE_TIMEOUT = 900; // 15 minutes in seconds

/**
 * Simple IP Geolocation Client Class
 */
class IPGeoClient {
    
    private $baseUrl;
    private $cache = [];
    private $cacheTimeout;
    
    public function __construct($baseUrl = API_BASE_URL, $cacheTimeout = CACHE_TIMEOUT) {
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->cacheTimeout = $cacheTimeout;
    }
    
    /**
     * Make HTTP GET request with cURL
     */
    private function makeRequest($endpoint) {
        $url = $this->baseUrl . '/' . ltrim($endpoint, '/');
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-IPGeoClient/1.0');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            throw new Exception("cURL Error: " . $error);
        }
        
        if ($httpCode === 429) {
            throw new Exception("Rate limit exceeded. Please wait before making more requests.");
        }
        
        if ($httpCode >= 400) {
            $errorData = json_decode($response, true);
            $errorMessage = isset($errorData['error']) ? $errorData['error'] : "HTTP $httpCode: Unknown error";
            throw new Exception($errorMessage);
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Invalid JSON response: " . json_last_error_msg());
        }
        
        return $data;
    }
    
    /**
     * Check if cached data is still valid
     */
    private function isCacheValid($key) {
        return isset($this->cache[$key]) && 
               (time() - $this->cache[$key]['timestamp']) < $this->cacheTimeout;
    }
    
    /**
     * Cache API result
     */
    private function cacheResult($key, $data) {
        $this->cache[$key] = [
            'data' => $data,
            'timestamp' => time()
        ];
    }
    
    /**
     * Look up IP geolocation information
     * 
     * @param string|null $ip IP address to lookup (null for current IP)
     * @return array Geolocation data
     */
    public function lookup($ip = null) {
        $cacheKey = $ip ?: 'current';
        
        // Check cache first
        if ($this->isCacheValid($cacheKey)) {
            echo "Using cached result for $cacheKey\n";
            return $this->cache[$cacheKey]['data'];
        }
        
        // Make API request
        $endpoint = $ip ? "/geo/$ip" : '/geo';
        $data = $this->makeRequest($endpoint);
        
        // Cache the result
        $this->cacheResult($cacheKey, $data);
        
        return $data;
    }
    
    /**
     * Get current IP address
     * 
     * @return string Current IP address
     */
    public function getCurrentIP() {
        $data = $this->makeRequest('/myip');
        return $data['ip'];
    }
    
    /**
     * Get API health status
     * 
     * @return array Health status
     */
    public function getHealthStatus() {
        return $this->makeRequest('/health');
    }
    
    /**
     * Get service statistics
     * 
     * @return array Service statistics
     */
    public function getStats() {
        return $this->makeRequest('/stats');
    }
    
    /**
     * Look up multiple IPs with rate limiting
     * 
     * @param array $ips Array of IP addresses
     * @param int $delayMs Delay between requests in milliseconds
     * @return array Array of lookup results
     */
    public function lookupBatch($ips, $delayMs = 500) {
        $results = [];
        
        foreach ($ips as $index => $ip) {
            try {
                $location = $this->lookup($ip);
                $results[] = array_merge(['ip' => $ip], $location);
            } catch (Exception $e) {
                $results[] = ['ip' => $ip, 'error' => $e->getMessage()];
            }
            
            // Add delay between requests (except for the last one)
            if ($index < count($ips) - 1) {
                usleep($delayMs * 1000); // Convert to microseconds
            }
        }
        
        return $results;
    }
    
    /**
     * Clear cache
     */
    public function clearCache() {
        $this->cache = [];
    }
}

/**
 * Simple function-based interface
 */
function getIPLocation($ip = null) {
    $url = API_BASE_URL . '/geo';
    if ($ip) {
        $url .= "/$ip";
    }
    
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => [
                'Accept: application/json',
                'User-Agent: PHP-SimpleClient/1.0'
            ],
            'timeout' => 30
        ]
    ]);
    
    $response = file_get_contents($url, false, $context);
    if ($response === false) {
        throw new Exception("Failed to fetch data from API");
    }
    
    return json_decode($response, true);
}

/**
 * Get current IP address
 */
function getCurrentIP() {
    $response = file_get_contents(API_BASE_URL . '/myip');
    if ($response === false) {
        throw new Exception("Failed to get current IP");
    }
    
    $data = json_decode($response, true);
    return $data['ip'];
}

/**
 * Utility function to validate IP address
 */
function isValidIP($ip) {
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

/**
 * Format location data into readable string
 */
function formatLocation($locationData) {
    $parts = [];
    
    if (!empty($locationData['city'])) {
        $parts[] = $locationData['city'];
    }
    if (!empty($locationData['region'])) {
        $parts[] = $locationData['region'];
    }
    if (!empty($locationData['country'])) {
        $parts[] = $locationData['country'];
    }
    
    return !empty($parts) ? implode(', ', $parts) : 'Unknown location';
}

/**
 * Calculate distance between two coordinates using Haversine formula
 */
function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    $earthRadius = 6371; // Earth's radius in kilometers
    
    $lat1 = deg2rad($lat1);
    $lon1 = deg2rad($lon1);
    $lat2 = deg2rad($lat2);
    $lon2 = deg2rad($lon2);
    
    $deltaLat = $lat2 - $lat1;
    $deltaLon = $lon2 - $lon1;
    
    $a = sin($deltaLat / 2) * sin($deltaLat / 2) +
         cos($lat1) * cos($lat2) *
         sin($deltaLon / 2) * sin($deltaLon / 2);
    
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    
    return $earthRadius * $c;
}

/**
 * Example usage and demonstrations
 */
function runExamples() {
    echo "=== IP Geolocation API Examples ===\n\n";
    
    // Create client instance
    $client = new IPGeoClient();
    
    // Example 1: Get current IP location
    try {
        echo "1. Getting your current location...\n";
        $currentLocation = $client->lookup();
        echo "Your IP: " . $currentLocation['ip'] . "\n";
        echo "Location: " . formatLocation($currentLocation) . "\n";
        echo "Coordinates: " . ($currentLocation['latitude'] ?? 'N/A') . ", " . 
             ($currentLocation['longitude'] ?? 'N/A') . "\n";
        echo "ISP: " . ($currentLocation['isp'] ?? 'Unknown') . "\n\n";
    } catch (Exception $e) {
        echo "Error getting current location: " . $e->getMessage() . "\n\n";
    }
    
    // Example 2: Look up specific IPs
    $testIPs = ['8.8.8.8', '1.1.1.1', '208.67.222.222'];
    
    echo "2. Looking up specific IP addresses...\n";
    foreach ($testIPs as $ip) {
        try {
            $location = $client->lookup($ip);
            echo "$ip -> " . formatLocation($location) . 
                 " (" . ($location['isp'] ?? 'Unknown ISP') . ")\n";
        } catch (Exception $e) {
            echo "Error looking up $ip: " . $e->getMessage() . "\n";
        }
    }
    echo "\n";
    
    // Example 3: Batch processing with rate limiting
    echo "3. Batch processing with rate limiting...\n";
    try {
        $batchResults = $client->lookupBatch(['8.8.8.8', '1.1.1.1'], 1000);
        foreach ($batchResults as $result) {
            if (isset($result['error'])) {
                echo $result['ip'] . " -> Error: " . $result['error'] . "\n";
            } else {
                echo $result['ip'] . " -> " . ($result['city'] ?? 'Unknown') . 
                     ", " . $result['country'] . "\n";
            }
        }
    } catch (Exception $e) {
        echo "Batch processing error: " . $e->getMessage() . "\n";
    }
    echo "\n";
    
    // Example 4: API health check
    echo "4. Checking API health...\n";
    try {
        $health = $client->getHealthStatus();
        echo "API Status: " . ($health['ok'] ? 'OK' : 'DOWN') . "\n";
        echo "Database Age: " . $health['dbAge'] . "\n";
        echo "Uptime: " . $health['uptime'] . " seconds\n";
    } catch (Exception $e) {
        echo "Health check failed: " . $e->getMessage() . "\n";
    }
    echo "\n";
    
    // Example 5: Service statistics
    echo "5. Getting service statistics...\n";
    try {
        $stats = $client->getStats();
        echo "Total Requests: " . $stats['totalRequests'] . "\n";
        echo "Average Response Time: " . $stats['avgResponseTime'] . "\n";
        echo "Uptime: " . $stats['uptime'] . "\n";
    } catch (Exception $e) {
        echo "Stats retrieval failed: " . $e->getMessage() . "\n";
    }
    echo "\n";
    
    // Example 6: Using simple function interface
    echo "6. Using simple function interface...\n";
    try {
        $location = getIPLocation('8.8.8.8');
        echo "Google DNS is located in: " . formatLocation($location) . "\n";
        
        $myIP = getCurrentIP();
        echo "Your IP address is: $myIP\n";
    } catch (Exception $e) {
        echo "Simple interface error: " . $e->getMessage() . "\n";
    }
    echo "\n";
    
    // Example 7: Distance calculation
    echo "7. Calculating distance between two locations...\n";
    try {
        $googleDNS = $client->lookup('8.8.8.8');
        $cloudflareDNS = $client->lookup('1.1.1.1');
        
        if (isset($googleDNS['latitude']) && isset($googleDNS['longitude']) &&
            isset($cloudflareDNS['latitude']) && isset($cloudflareDNS['longitude'])) {
            
            $distance = calculateDistance(
                $googleDNS['latitude'], $googleDNS['longitude'],
                $cloudflareDNS['latitude'], $cloudflareDNS['longitude']
            );
            
            echo "Distance between Google DNS and Cloudflare DNS: " . 
                 number_format($distance, 2) . " km\n";
        }
    } catch (Exception $e) {
        echo "Distance calculation error: " . $e->getMessage() . "\n";
    }
}

/**
 * Web interface example (for web usage)
 */
function webExample() {
    // Only run if accessed via web browser
    if (php_sapi_name() !== 'cli') {
        header('Content-Type: application/json');
        
        try {
            $ip = $_GET['ip'] ?? null;
            
            // Validate IP if provided
            if ($ip && !isValidIP($ip)) {
                throw new Exception("Invalid IP address format");
            }
            
            $client = new IPGeoClient();
            $result = $client->lookup($ip);
            
            echo json_encode($result, JSON_PRETTY_PRINT);
            
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['error' => $e->getMessage()], JSON_PRETTY_PRINT);
        }
        exit;
    }
}

/**
 * WordPress plugin example
 */
function wordpress_ip_geolocation_shortcode($atts) {
    $atts = shortcode_atts([
        'ip' => null,
        'show' => 'city,country'
    ], $atts);
    
    try {
        $client = new IPGeoClient();
        $location = $client->lookup($atts['ip']);
        
        $showFields = array_map('trim', explode(',', $atts['show']));
        $output = [];
        
        foreach ($showFields as $field) {
            if (isset($location[$field]) && !empty($location[$field])) {
                $output[] = $location[$field];
            }
        }
        
        return implode(', ', $output);
        
    } catch (Exception $e) {
        return "Error: " . $e->getMessage();
    }
}

// Register WordPress shortcode if WordPress is detected
if (function_exists('add_shortcode')) {
    add_shortcode('ip_location', 'wordpress_ip_geolocation_shortcode');
}

// Run examples if script is executed directly from command line
if (php_sapi_name() === 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    runExamples();
} else {
    // Handle web requests
    webExample();
}

?>

<?php
/*
Usage Examples:

1. Command Line:
   php ip-geo-example.php

2. Web Browser:
   http://yoursite.com/ip-geo-example.php
   http://yoursite.com/ip-geo-example.php?ip=8.8.8.8

3. WordPress Shortcode:
   [ip_location]
   [ip_location ip="8.8.8.8"]
   [ip_location ip="8.8.8.8" show="city,country,isp"]

4. Laravel Integration:

   <?php
   // In a Laravel controller
   class IPGeoController extends Controller {
       public function lookup(Request $request) {
           $ip = $request->input('ip');
           
           try {
               $client = new IPGeoClient();
               $location = $client->lookup($ip);
               
               return response()->json($location);
           } catch (Exception $e) {
               return response()->json(['error' => $e->getMessage()], 400);
           }
       }
   }
   ?>

5. Symfony Integration:

   <?php
   // In a Symfony controller
   class IPGeoController extends AbstractController {
       /**
        * @Route("/api/geo/{ip}", name="ip_geo_lookup", defaults={"ip"=null})
        */
       public function lookup($ip = null): JsonResponse {
           try {
               $client = new IPGeoClient();
               $location = $client->lookup($ip);
               
               return $this->json($location);
           } catch (Exception $e) {
               return $this->json(['error' => $e->getMessage()], 400);
           }
       }
   }
   ?>

6. Composer Package (composer.json):

   {
       "name": "yourname/ip-geolocation-client",
       "description": "PHP client for Free IP Geolocation API",
       "type": "library",
       "require": {
           "php": ">=7.4",
           "ext-curl": "*",
           "ext-json": "*"
       },
       "autoload": {
           "psr-4": {
               "IPGeo\\": "src/"
           }
       }
   }

Installation Requirements:
- PHP 7.4 or higher
- cURL extension (usually enabled by default)
- JSON extension (usually enabled by default)

For Ubuntu/Debian:
sudo apt-get install php php-curl php-json

For CentOS/RHEL:
sudo yum install php php-curl php-json

For Windows (XAMPP):
Ensure curl and json extensions are enabled in php.ini
*/
?>