package main

/*
Go Example for Free IP Geolocation API

This example demonstrates various ways to use the API with Go
including error handling, caching, rate limiting, and concurrent processing.

Features:
- HTTP client with timeout and retry logic
- JSON marshaling/unmarshaling
- In-memory caching with TTL
- Rate limiting and batch processing
- Concurrent lookups with goroutines
- Context support for cancellation
*/

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math"
	"net/http"
	"net/url"
	"sync"
	"time"
)

const (
	BaseURL      = "https://ip-address.replit.app/api"
	DefaultTimeout = 30 * time.Second
	CacheTimeout   = 15 * time.Minute
)

// IPLocation represents the geolocation data for an IP address
type IPLocation struct {
	IP          string  `json:"ip"`
	CountryCode string  `json:"countryCode"`
	Country     string  `json:"country"`
	RegionCode  string  `json:"regionCode,omitempty"`
	Region      string  `json:"region,omitempty"`
	City        string  `json:"city,omitempty"`
	PostalCode  string  `json:"postalCode,omitempty"`
	Latitude    float64 `json:"latitude,omitempty"`
	Longitude   float64 `json:"longitude,omitempty"`
	Timezone    string  `json:"timezone,omitempty"`
	ISP         string  `json:"isp,omitempty"`
	ASN         int     `json:"asn,omitempty"`
}

// CurrentIP represents the response from /myip endpoint
type CurrentIP struct {
	IP string `json:"ip"`
}

// HealthStatus represents the API health status
type HealthStatus struct {
	OK     bool   `json:"ok"`
	DbAge  string `json:"dbAge"`
	Uptime int    `json:"uptime"`
}

// ServiceStats represents service statistics
type ServiceStats struct {
	TotalRequests   string `json:"totalRequests"`
	AvgResponseTime string `json:"avgResponseTime"`
	Uptime          string `json:"uptime"`
	CacheHitRate    string `json:"cacheHitRate,omitempty"`
}

// APIError represents an API error response
type APIError struct {
	Error   string `json:"error"`
	Code    int    `json:"code,omitempty"`
	Message string `json:"message,omitempty"`
}

func (e *APIError) Error() string {
	if e.Message != "" {
		return fmt.Sprintf("API Error (%d): %s - %s", e.Code, e.Error, e.Message)
	}
	return fmt.Sprintf("API Error: %s", e.Error)
}

// CacheEntry represents a cached result with timestamp
type cacheEntry struct {
	data      interface{}
	timestamp time.Time
}

// IPGeoClient is the main client for the IP Geolocation API
type IPGeoClient struct {
	httpClient   *http.Client
	baseURL      string
	cache        map[string]*cacheEntry
	cacheMutex   sync.RWMutex
	cacheTimeout time.Duration
}

// NewIPGeoClient creates a new IP geolocation client
func NewIPGeoClient() *IPGeoClient {
	return &IPGeoClient{
		httpClient: &http.Client{
			Timeout: DefaultTimeout,
		},
		baseURL:      BaseURL,
		cache:        make(map[string]*cacheEntry),
		cacheTimeout: CacheTimeout,
	}
}

// NewIPGeoClientWithConfig creates a client with custom configuration
func NewIPGeoClientWithConfig(baseURL string, timeout, cacheTimeout time.Duration) *IPGeoClient {
	return &IPGeoClient{
		httpClient: &http.Client{
			Timeout: timeout,
		},
		baseURL:      baseURL,
		cache:        make(map[string]*cacheEntry),
		cacheTimeout: cacheTimeout,
	}
}

// makeRequest performs an HTTP GET request with error handling
func (c *IPGeoClient) makeRequest(ctx context.Context, endpoint string) ([]byte, error) {
	u, err := url.JoinPath(c.baseURL, endpoint)
	if err != nil {
		return nil, fmt.Errorf("invalid URL: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, "GET", u, nil)
	if err != nil {
		return nil, fmt.Errorf("creating request: %w", err)
	}

	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", "Go-IPGeoClient/1.0")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("reading response body: %w", err)
	}

	if resp.StatusCode == 429 {
		return nil, fmt.Errorf("rate limit exceeded: please wait before making more requests")
	}

	if resp.StatusCode >= 400 {
		var apiErr APIError
		if err := json.Unmarshal(body, &apiErr); err == nil {
			apiErr.Code = resp.StatusCode
			return nil, &apiErr
		}
		return nil, fmt.Errorf("HTTP %d: %s", resp.StatusCode, string(body))
	}

	return body, nil
}

// getCachedResult retrieves cached data if still valid
func (c *IPGeoClient) getCachedResult(key string) (interface{}, bool) {
	c.cacheMutex.RLock()
	defer c.cacheMutex.RUnlock()

	entry, exists := c.cache[key]
	if !exists {
		return nil, false
	}

	if time.Since(entry.timestamp) > c.cacheTimeout {
		return nil, false
	}

	fmt.Printf("Using cached result for %s\n", key)
	return entry.data, true
}

// setCachedResult stores data in cache
func (c *IPGeoClient) setCachedResult(key string, data interface{}) {
	c.cacheMutex.Lock()
	defer c.cacheMutex.Unlock()

	c.cache[key] = &cacheEntry{
		data:      data,
		timestamp: time.Now(),
	}
}

// Lookup gets geolocation information for an IP address
func (c *IPGeoClient) Lookup(ctx context.Context, ip string) (*IPLocation, error) {
	cacheKey := ip
	if ip == "" {
		cacheKey = "current"
	}

	// Check cache first
	if cached, found := c.getCachedResult(cacheKey); found {
		if location, ok := cached.(*IPLocation); ok {
			return location, nil
		}
	}

	// Make API request
	endpoint := "/geo"
	if ip != "" {
		endpoint = fmt.Sprintf("/geo/%s", ip)
	}

	body, err := c.makeRequest(ctx, endpoint)
	if err != nil {
		return nil, err
	}

	var location IPLocation
	if err := json.Unmarshal(body, &location); err != nil {
		return nil, fmt.Errorf("unmarshaling response: %w", err)
	}

	// Cache the result
	c.setCachedResult(cacheKey, &location)

	return &location, nil
}

// GetCurrentIP gets the current IP address
func (c *IPGeoClient) GetCurrentIP(ctx context.Context) (string, error) {
	body, err := c.makeRequest(ctx, "/myip")
	if err != nil {
		return "", err
	}

	var currentIP CurrentIP
	if err := json.Unmarshal(body, &currentIP); err != nil {
		return "", fmt.Errorf("unmarshaling response: %w", err)
	}

	return currentIP.IP, nil
}

// GetHealthStatus gets the API health status
func (c *IPGeoClient) GetHealthStatus(ctx context.Context) (*HealthStatus, error) {
	body, err := c.makeRequest(ctx, "/health")
	if err != nil {
		return nil, err
	}

	var health HealthStatus
	if err := json.Unmarshal(body, &health); err != nil {
		return nil, fmt.Errorf("unmarshaling response: %w", err)
	}

	return &health, nil
}

// GetStats gets service statistics
func (c *IPGeoClient) GetStats(ctx context.Context) (*ServiceStats, error) {
	body, err := c.makeRequest(ctx, "/stats")
	if err != nil {
		return nil, err
	}

	var stats ServiceStats
	if err := json.Unmarshal(body, &stats); err != nil {
		return nil, fmt.Errorf("unmarshaling response: %w", err)
	}

	return &stats, nil
}

// LookupResult represents the result of a batch lookup operation
type LookupResult struct {
	IP       string
	Location *IPLocation
	Error    error
}

// LookupBatch performs batch IP lookups with rate limiting
func (c *IPGeoClient) LookupBatch(ctx context.Context, ips []string, delay time.Duration) []LookupResult {
	results := make([]LookupResult, len(ips))

	for i, ip := range ips {
		location, err := c.Lookup(ctx, ip)
		results[i] = LookupResult{
			IP:       ip,
			Location: location,
			Error:    err,
		}

		// Add delay between requests (except for the last one)
		if i < len(ips)-1 {
			select {
			case <-ctx.Done():
				return results[:i+1] // Return partial results if context is cancelled
			case <-time.After(delay):
			}
		}
	}

	return results
}

// LookupConcurrent performs concurrent IP lookups with a worker pool
func (c *IPGeoClient) LookupConcurrent(ctx context.Context, ips []string, workers int) []LookupResult {
	if workers <= 0 {
		workers = 5 // Default worker count
	}

	jobs := make(chan string, len(ips))
	results := make(chan LookupResult, len(ips))

	// Start workers
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for ip := range jobs {
				location, err := c.Lookup(ctx, ip)
				results <- LookupResult{
					IP:       ip,
					Location: location,
					Error:    err,
				}
			}
		}()
	}

	// Send jobs
	go func() {
		defer close(jobs)
		for _, ip := range ips {
			select {
			case jobs <- ip:
			case <-ctx.Done():
				return
			}
		}
	}()

	// Close results channel when all workers are done
	go func() {
		wg.Wait()
		close(results)
	}()

	// Collect results
	var lookupResults []LookupResult
	for result := range results {
		lookupResults = append(lookupResults, result)
	}

	return lookupResults
}

// ClearCache clears all cached data
func (c *IPGeoClient) ClearCache() {
	c.cacheMutex.Lock()
	defer c.cacheMutex.Unlock()
	c.cache = make(map[string]*cacheEntry)
}

// Utility functions

// FormatLocation formats location data into a readable string
func FormatLocation(location *IPLocation) string {
	var parts []string

	if location.City != "" {
		parts = append(parts, location.City)
	}
	if location.Region != "" {
		parts = append(parts, location.Region)
	}
	if location.Country != "" {
		parts = append(parts, location.Country)
	}

	if len(parts) == 0 {
		return "Unknown location"
	}

	result := ""
	for i, part := range parts {
		if i > 0 {
			result += ", "
		}
		result += part
	}

	return result
}

// CalculateDistance calculates the distance between two coordinates using the Haversine formula
func CalculateDistance(lat1, lon1, lat2, lon2 float64) float64 {
	const earthRadius = 6371 // Earth's radius in kilometers

	lat1Rad := lat1 * math.Pi / 180
	lat2Rad := lat2 * math.Pi / 180
	deltaLat := (lat2 - lat1) * math.Pi / 180
	deltaLon := (lon2 - lon1) * math.Pi / 180

	a := math.Sin(deltaLat/2)*math.Sin(deltaLat/2) +
		math.Cos(lat1Rad)*math.Cos(lat2Rad)*
			math.Sin(deltaLon/2)*math.Sin(deltaLon/2)

	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	return earthRadius * c
}

// Example usage and demonstrations
func runExamples() {
	fmt.Println("=== IP Geolocation API Examples ===\n")

	// Create client
	client := NewIPGeoClient()
	ctx := context.Background()

	// Example 1: Get current IP location
	fmt.Println("1. Getting your current location...")
	currentLocation, err := client.Lookup(ctx, "")
	if err != nil {
		fmt.Printf("Error getting current location: %v\n", err)
	} else {
		fmt.Printf("Your IP: %s\n", currentLocation.IP)
		fmt.Printf("Location: %s\n", FormatLocation(currentLocation))
		fmt.Printf("Coordinates: %.4f, %.4f\n", currentLocation.Latitude, currentLocation.Longitude)
		fmt.Printf("ISP: %s\n", currentLocation.ISP)
	}
	fmt.Println()

	// Example 2: Look up specific IPs
	testIPs := []string{"8.8.8.8", "1.1.1.1", "208.67.222.222"}

	fmt.Println("2. Looking up specific IP addresses...")
	for _, ip := range testIPs {
		location, err := client.Lookup(ctx, ip)
		if err != nil {
			fmt.Printf("Error looking up %s: %v\n", ip, err)
		} else {
			fmt.Printf("%s -> %s (%s)\n", ip, FormatLocation(location), location.ISP)
		}
	}
	fmt.Println()

	// Example 3: Batch processing with rate limiting
	fmt.Println("3. Batch processing with rate limiting...")
	batchIPs := []string{"8.8.8.8", "1.1.1.1"}
	results := client.LookupBatch(ctx, batchIPs, 1*time.Second)

	for _, result := range results {
		if result.Error != nil {
			fmt.Printf("%s -> Error: %v\n", result.IP, result.Error)
		} else {
			fmt.Printf("%s -> %s\n", result.IP, FormatLocation(result.Location))
		}
	}
	fmt.Println()

	// Example 4: Concurrent processing
	fmt.Println("4. Concurrent processing...")
	concurrentIPs := []string{"8.8.8.8", "1.1.1.1", "208.67.222.222", "9.9.9.9"}
	concurrentResults := client.LookupConcurrent(ctx, concurrentIPs, 3)

	for _, result := range concurrentResults {
		if result.Error != nil {
			fmt.Printf("%s -> Error: %v\n", result.IP, result.Error)
		} else {
			fmt.Printf("%s -> %s\n", result.IP, FormatLocation(result.Location))
		}
	}
	fmt.Println()

	// Example 5: API health check
	fmt.Println("5. Checking API health...")
	health, err := client.GetHealthStatus(ctx)
	if err != nil {
		fmt.Printf("Health check failed: %v\n", err)
	} else {
		status := "DOWN"
		if health.OK {
			status = "OK"
		}
		fmt.Printf("API Status: %s\n", status)
		fmt.Printf("Database Age: %s\n", health.DbAge)
		fmt.Printf("Uptime: %d seconds\n", health.Uptime)
	}
	fmt.Println()

	// Example 6: Service statistics
	fmt.Println("6. Getting service statistics...")
	stats, err := client.GetStats(ctx)
	if err != nil {
		fmt.Printf("Stats retrieval failed: %v\n", err)
	} else {
		fmt.Printf("Total Requests: %s\n", stats.TotalRequests)
		fmt.Printf("Average Response Time: %s\n", stats.AvgResponseTime)
		fmt.Printf("Uptime: %s\n", stats.Uptime)
	}
	fmt.Println()

	// Example 7: Distance calculation
	fmt.Println("7. Calculating distance between Google and Cloudflare DNS...")
	googleDNS, err1 := client.Lookup(ctx, "8.8.8.8")
	cloudflareDNS, err2 := client.Lookup(ctx, "1.1.1.1")

	if err1 == nil && err2 == nil {
		distance := CalculateDistance(
			googleDNS.Latitude, googleDNS.Longitude,
			cloudflareDNS.Latitude, cloudflareDNS.Longitude,
		)
		fmt.Printf("Distance: %.2f km\n", distance)
	} else {
		fmt.Printf("Error calculating distance: %v, %v\n", err1, err2)
	}
}

func main() {
	runExamples()
}

/*
Usage Examples:

1. Basic Usage:
   go run ip-geo-example.go

2. As a Module:
   Create go.mod:
   module your-project
   go 1.21

   Then import and use:
   import "./ip-geo-client"

3. With Gorilla Mux (HTTP Server):

   package main

   import (
       "encoding/json"
       "net/http"
       "github.com/gorilla/mux"
   )

   func main() {
       client := NewIPGeoClient()
       r := mux.NewRouter()

       r.HandleFunc("/geo/{ip}", func(w http.ResponseWriter, r *http.Request) {
           vars := mux.Vars(r)
           ip := vars["ip"]

           location, err := client.Lookup(r.Context(), ip)
           if err != nil {
               http.Error(w, err.Error(), http.StatusBadRequest)
               return
           }

           w.Header().Set("Content-Type", "application/json")
           json.NewEncoder(w).Encode(location)
       }).Methods("GET")

       http.ListenAndServe(":8080", r)
   }

4. With Gin Framework:

   package main

   import (
       "net/http"
       "github.com/gin-gonic/gin"
   )

   func main() {
       client := NewIPGeoClient()
       r := gin.Default()

       r.GET("/geo/:ip", func(c *gin.Context) {
           ip := c.Param("ip")

           location, err := client.Lookup(c, ip)
           if err != nil {
               c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
               return
           }

           c.JSON(http.StatusOK, location)
       })

       r.Run(":8080")
   }

5. With Context Timeout:

   ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
   defer cancel()

   location, err := client.Lookup(ctx, "8.8.8.8")
   if err != nil {
       log.Fatal(err)
   }

Installation:
go mod init your-project-name
go mod tidy
go run main.go

Dependencies (optional):
go get github.com/gorilla/mux    # For HTTP routing
go get github.com/gin-gonic/gin  # For Gin framework
*/