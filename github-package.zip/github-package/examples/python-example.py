"""
Python Example for Free IP Geolocation API

This example demonstrates various ways to use the API with Python
including error handling, rate limiting, and caching.

Requirements:
    pip install requests
"""

import requests
import time
import json
from typing import Optional, Dict, List, Any
from datetime import datetime, timedelta

BASE_URL = 'https://ip-address.replit.app/api'

class IPGeoClient:
    """
    A comprehensive client for the Free IP Geolocation API
    
    Features:
    - Automatic caching with configurable timeout
    - Rate limiting protection
    - Comprehensive error handling
    - Batch processing with delays
    - Retry logic for failed requests
    """
    
    def __init__(self, base_url: str = BASE_URL, cache_timeout: int = 900):
        """
        Initialize the IP Geolocation client
        
        Args:
            base_url (str): Base URL for the API
            cache_timeout (int): Cache timeout in seconds (default: 15 minutes)
        """
        self.base_url = base_url.rstrip('/')
        self.cache = {}
        self.cache_timeout = cache_timeout
        self.session = requests.Session()
        
        # Set default headers
        self.session.headers.update({
            'User-Agent': 'Python-IPGeoClient/1.0',
            'Accept': 'application/json'
        })
    
    def _is_cache_valid(self, cache_key: str) -> bool:
        """Check if cached data is still valid"""
        if cache_key not in self.cache:
            return False
        
        cached_time = self.cache[cache_key]['timestamp']
        return datetime.now() - cached_time < timedelta(seconds=self.cache_timeout)
    
    def _cache_result(self, cache_key: str, data: Dict[str, Any]) -> None:
        """Cache the API result"""
        self.cache[cache_key] = {
            'data': data,
            'timestamp': datetime.now()
        }
    
    def _make_request(self, endpoint: str) -> Dict[str, Any]:
        """Make API request with error handling"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 429:
                raise requests.exceptions.RequestException(
                    "Rate limit exceeded. Please wait before making more requests."
                )
            
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.Timeout:
            raise requests.exceptions.RequestException("Request timed out")
        except requests.exceptions.ConnectionError:
            raise requests.exceptions.RequestException("Connection error")
        except requests.exceptions.HTTPError as e:
            try:
                error_data = response.json()
                raise requests.exceptions.RequestException(
                    f"HTTP {response.status_code}: {error_data.get('error', 'Unknown error')}"
                )
            except json.JSONDecodeError:
                raise requests.exceptions.RequestException(f"HTTP {response.status_code}: {response.text}")
    
    def lookup(self, ip: Optional[str] = None) -> Dict[str, Any]:
        """
        Look up IP geolocation information
        
        Args:
            ip (str, optional): IP address to lookup. If None, uses current IP
            
        Returns:
            dict: Geolocation information
            
        Raises:
            requests.exceptions.RequestException: If the API request fails
        """
        cache_key = ip if ip else 'current'
        
        # Check cache first
        if self._is_cache_valid(cache_key):
            print(f"Using cached result for {cache_key}")
            return self.cache[cache_key]['data']
        
        # Make API request
        endpoint = f'/geo/{ip}' if ip else '/geo'
        data = self._make_request(endpoint)
        
        # Cache the result
        self._cache_result(cache_key, data)
        
        return data
    
    def get_current_ip(self) -> str:
        """
        Get the current IP address
        
        Returns:
            str: Current IP address
        """
        data = self._make_request('/myip')
        return data['ip']
    
    def get_health_status(self) -> Dict[str, Any]:
        """
        Get API health status
        
        Returns:
            dict: Health status information
        """
        return self._make_request('/health')
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get service statistics
        
        Returns:
            dict: Service statistics
        """
        return self._make_request('/stats')
    
    def lookup_batch(self, ips: List[str], delay_seconds: float = 0.5) -> List[Dict[str, Any]]:
        """
        Look up multiple IPs with rate limiting
        
        Args:
            ips (list): List of IP addresses to lookup
            delay_seconds (float): Delay between requests in seconds
            
        Returns:
            list: List of lookup results
        """
        results = []
        
        for i, ip in enumerate(ips):
            try:
                result = self.lookup(ip)
                results.append({'ip': ip, **result})
            except Exception as e:
                results.append({'ip': ip, 'error': str(e)})
            
            # Add delay between requests (except for the last one)
            if i < len(ips) - 1:
                time.sleep(delay_seconds)
        
        return results
    
    def clear_cache(self) -> None:
        """Clear the cache"""
        self.cache.clear()

# Simple function-based interface
def get_ip_location(ip: Optional[str] = None) -> Dict[str, Any]:
    """
    Simple function to get IP geolocation information
    
    Args:
        ip (str, optional): IP address to lookup
        
    Returns:
        dict: Geolocation information
    """
    url = f"{BASE_URL}/geo"
    if ip:
        url += f"/{ip}"
    
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    return response.json()

def get_current_ip() -> str:
    """Get current IP address"""
    response = requests.get(f"{BASE_URL}/myip", timeout=10)
    response.raise_for_status()
    return response.json()['ip']

# Example usage and demonstrations
def examples():
    """Demonstrate various API usage patterns"""
    print("=== IP Geolocation API Examples ===\n")
    
    # Create client instance
    client = IPGeoClient()
    
    # Example 1: Get current IP location
    try:
        print("1. Getting your current location...")
        current_location = client.lookup()
        print(f"Your IP: {current_location['ip']}")
        print(f"Location: {current_location.get('city', 'Unknown')}, "
              f"{current_location.get('region', 'Unknown')}, "
              f"{current_location['country']}")
        print(f"Coordinates: {current_location.get('latitude', 'N/A')}, "
              f"{current_location.get('longitude', 'N/A')}")
        print(f"ISP: {current_location.get('isp', 'Unknown')}\n")
    except Exception as e:
        print(f"Error getting current location: {e}\n")
    
    # Example 2: Look up specific IPs
    test_ips = ['8.8.8.8', '1.1.1.1', '208.67.222.222']
    
    print("2. Looking up specific IP addresses...")
    for ip in test_ips:
        try:
            location = client.lookup(ip)
            print(f"{ip} -> {location.get('city', 'Unknown')}, "
                  f"{location['country']} ({location.get('isp', 'Unknown ISP')})")
        except Exception as e:
            print(f"Error looking up {ip}: {e}")
    
    # Example 3: Batch processing with rate limiting
    print("\n3. Batch processing with rate limiting...")
    try:
        batch_results = client.lookup_batch(['8.8.8.8', '1.1.1.1'], delay_seconds=1.0)
        for result in batch_results:
            if 'error' in result:
                print(f"{result['ip']} -> Error: {result['error']}")
            else:
                print(f"{result['ip']} -> {result.get('city', 'Unknown')}, "
                      f"{result['country']}")
    except Exception as e:
        print(f"Batch processing error: {e}")
    
    # Example 4: API health check
    print("\n4. Checking API health...")
    try:
        health = client.get_health_status()
        print(f"API Status: {'OK' if health['ok'] else 'DOWN'}")
        print(f"Database Age: {health['dbAge']}")
        print(f"Uptime: {health['uptime']} seconds")
    except Exception as e:
        print(f"Health check failed: {e}")
    
    # Example 5: Service statistics
    print("\n5. Getting service statistics...")
    try:
        stats = client.get_stats()
        print(f"Total Requests: {stats['totalRequests']}")
        print(f"Average Response Time: {stats['avgResponseTime']}")
        print(f"Uptime: {stats['uptime']}")
    except Exception as e:
        print(f"Stats retrieval failed: {e}")
    
    # Example 6: Using simple function interface
    print("\n6. Using simple function interface...")
    try:
        location = get_ip_location('8.8.8.8')
        print(f"Google DNS is located in: {location.get('city', 'Unknown')}, "
              f"{location['country']}")
        
        my_ip = get_current_ip()
        print(f"Your IP address is: {my_ip}")
    except Exception as e:
        print(f"Simple interface error: {e}")

# Utility functions for common use cases
def validate_ip(ip: str) -> bool:
    """
    Basic IP address validation
    
    Args:
        ip (str): IP address to validate
        
    Returns:
        bool: True if IP appears valid
    """
    import re
    
    # IPv4 pattern
    ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    
    # IPv6 pattern (simplified)
    ipv6_pattern = r'^[0-9a-fA-F:]+$'
    
    return bool(re.match(ipv4_pattern, ip) or re.match(ipv6_pattern, ip))

def format_location_string(location_data: Dict[str, Any]) -> str:
    """
    Format location data into a readable string
    
    Args:
        location_data (dict): Location data from API
        
    Returns:
        str: Formatted location string
    """
    parts = []
    
    if location_data.get('city'):
        parts.append(location_data['city'])
    
    if location_data.get('region'):
        parts.append(location_data['region'])
    
    if location_data.get('country'):
        parts.append(location_data['country'])
    
    return ', '.join(parts) or 'Unknown location'

def get_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate distance between two coordinates using Haversine formula
    
    Args:
        lat1, lon1: First coordinate pair
        lat2, lon2: Second coordinate pair
        
    Returns:
        float: Distance in kilometers
    """
    import math
    
    R = 6371  # Earth's radius in kilometers
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)
    
    a = (math.sin(delta_lat / 2) * math.sin(delta_lat / 2) +
         math.cos(lat1_rad) * math.cos(lat2_rad) *
         math.sin(delta_lon / 2) * math.sin(delta_lon / 2))
    
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

if __name__ == "__main__":
    examples()

"""
Installation and Usage:

1. Install requests:
   pip install requests

2. Save this file as ip_geo_example.py

3. Run the examples:
   python ip_geo_example.py

4. Or use as a module:
   
   from ip_geo_example import IPGeoClient
   
   client = IPGeoClient()
   location = client.lookup('8.8.8.8')
   print(location)

Advanced Usage Examples:

# Create client with custom settings
client = IPGeoClient(
    base_url='https://your-custom-instance.com/api',
    cache_timeout=1800  # 30 minutes cache
)

# Use with context manager for automatic cleanup
class IPGeoContextClient(IPGeoClient):
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.session.close()
        self.clear_cache()

with IPGeoContextClient() as client:
    location = client.lookup('8.8.8.8')
    print(location)

# Async version using aiohttp (requires: pip install aiohttp)
import asyncio
import aiohttp

async def async_lookup(ip=None):
    url = f"{BASE_URL}/geo"
    if ip:
        url += f"/{ip}"
    
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.json()

# Run async example
# asyncio.run(async_lookup('8.8.8.8'))
"""