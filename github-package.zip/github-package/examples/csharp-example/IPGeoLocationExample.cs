/**
 * C# Example for Free IP Geolocation API
 * 
 * This example demonstrates how to use the API with C# using
 * HttpClient and System.Text.Json for modern .NET applications.
 * 
 * Features:
 * - Async/await pattern with HttpClient
 * - JSON serialization with System.Text.Json
 * - Error handling and retries
 * - Caching with MemoryCache
 * - Rate limiting and batch processing
 * - Dependency injection ready
 */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace IPGeoLocation
{
    // Data models for JSON deserialization
    public class IPLocationResponse
    {
        [JsonPropertyName("ip")]
        public string IP { get; set; } = string.Empty;

        [JsonPropertyName("countryCode")]
        public string? CountryCode { get; set; }

        [JsonPropertyName("country")]
        public string? Country { get; set; }

        [JsonPropertyName("regionCode")]
        public string? RegionCode { get; set; }

        [JsonPropertyName("region")]
        public string? Region { get; set; }

        [JsonPropertyName("city")]
        public string? City { get; set; }

        [JsonPropertyName("postalCode")]
        public string? PostalCode { get; set; }

        [JsonPropertyName("latitude")]
        public double? Latitude { get; set; }

        [JsonPropertyName("longitude")]
        public double? Longitude { get; set; }

        [JsonPropertyName("timezone")]
        public string? Timezone { get; set; }

        [JsonPropertyName("isp")]
        public string? ISP { get; set; }

        [JsonPropertyName("asn")]
        public int? ASN { get; set; }

        public override string ToString()
        {
            var parts = new List<string>();
            if (!string.IsNullOrEmpty(City)) parts.Add(City);
            if (!string.IsNullOrEmpty(Region)) parts.Add(Region);
            if (!string.IsNullOrEmpty(Country)) parts.Add(Country);
            
            return parts.Any() ? string.Join(", ", parts) : "Unknown location";
        }
    }

    public class CurrentIPResponse
    {
        [JsonPropertyName("ip")]
        public string IP { get; set; } = string.Empty;
    }

    public class HealthStatusResponse
    {
        [JsonPropertyName("ok")]
        public bool OK { get; set; }

        [JsonPropertyName("dbAge")]
        public string? DbAge { get; set; }

        [JsonPropertyName("uptime")]
        public int Uptime { get; set; }
    }

    public class ServiceStatsResponse
    {
        [JsonPropertyName("totalRequests")]
        public string? TotalRequests { get; set; }

        [JsonPropertyName("avgResponseTime")]
        public string? AvgResponseTime { get; set; }

        [JsonPropertyName("uptime")]
        public string? Uptime { get; set; }

        [JsonPropertyName("cacheHitRate")]
        public string? CacheHitRate { get; set; }
    }

    public class APIErrorResponse
    {
        [JsonPropertyName("error")]
        public string? Error { get; set; }

        [JsonPropertyName("code")]
        public int? Code { get; set; }

        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }

    public class IPGeoLocationException : Exception
    {
        public int? StatusCode { get; }

        public IPGeoLocationException(string message) : base(message) { }

        public IPGeoLocationException(string message, int statusCode) : base(message)
        {
            StatusCode = statusCode;
        }

        public IPGeoLocationException(string message, Exception innerException) : base(message, innerException) { }
    }

    // Configuration options
    public class IPGeoClientOptions
    {
        public string BaseUrl { get; set; } = "https://ip-address.replit.app/api";
        public TimeSpan RequestTimeout { get; set; } = TimeSpan.FromSeconds(30);
        public TimeSpan CacheTimeout { get; set; } = TimeSpan.FromMinutes(15);
        public int MaxRetries { get; set; } = 3;
        public TimeSpan RetryDelay { get; set; } = TimeSpan.FromSeconds(1);
    }

    // Result wrapper for batch operations
    public class LookupResult
    {
        public string IP { get; set; } = string.Empty;
        public IPLocationResponse? Location { get; set; }
        public Exception? Error { get; set; }
        public bool IsSuccess => Error == null && Location != null;
    }

    // Main client interface
    public interface IIPGeoClient
    {
        Task<IPLocationResponse> LookupAsync(string? ip = null, CancellationToken cancellationToken = default);
        Task<string> GetCurrentIPAsync(CancellationToken cancellationToken = default);
        Task<HealthStatusResponse> GetHealthStatusAsync(CancellationToken cancellationToken = default);
        Task<ServiceStatsResponse> GetStatsAsync(CancellationToken cancellationToken = default);
        Task<IEnumerable<LookupResult>> LookupBatchAsync(IEnumerable<string> ips, TimeSpan delay, CancellationToken cancellationToken = default);
        Task<IEnumerable<LookupResult>> LookupConcurrentAsync(IEnumerable<string> ips, int maxConcurrency = 5, CancellationToken cancellationToken = default);
        void ClearCache();
    }

    // Main IP Geolocation client
    public class IPGeoClient : IIPGeoClient, IDisposable
    {
        private readonly HttpClient _httpClient;
        private readonly IMemoryCache _cache;
        private readonly ILogger<IPGeoClient>? _logger;
        private readonly IPGeoClientOptions _options;
        private readonly JsonSerializerOptions _jsonOptions;
        private readonly SemaphoreSlim _rateLimitSemaphore;
        private bool _disposed;

        public IPGeoClient() : this(new HttpClient(), null, null, new IPGeoClientOptions()) { }

        public IPGeoClient(HttpClient httpClient, IMemoryCache? cache = null, ILogger<IPGeoClient>? logger = null, IPGeoClientOptions? options = null)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _cache = cache ?? new MemoryCache(new MemoryCacheOptions());
            _logger = logger;
            _options = options ?? new IPGeoClientOptions();

            _httpClient.BaseAddress ??= new Uri(_options.BaseUrl);
            _httpClient.Timeout = _options.RequestTimeout;
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "CSharp-IPGeoClient/1.0");

            _jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                NumberHandling = JsonNumberHandling.AllowReadingFromString
            };

            // Allow up to 2 requests per second (120 per minute)
            _rateLimitSemaphore = new SemaphoreSlim(2, 2);
        }

        public async Task<IPLocationResponse> LookupAsync(string? ip = null, CancellationToken cancellationToken = default)
        {
            var cacheKey = ip ?? "current";

            // Check cache first
            if (_cache.TryGetValue(cacheKey, out IPLocationResponse? cachedResult))
            {
                _logger?.LogDebug("Using cached result for {IP}", cacheKey);
                return cachedResult!;
            }

            var endpoint = string.IsNullOrEmpty(ip) ? "geo" : $"geo/{ip}";
            var result = await MakeRequestAsync<IPLocationResponse>(endpoint, cancellationToken);

            // Cache the result
            _cache.Set(cacheKey, result, _options.CacheTimeout);

            return result;
        }

        public async Task<string> GetCurrentIPAsync(CancellationToken cancellationToken = default)
        {
            var result = await MakeRequestAsync<CurrentIPResponse>("myip", cancellationToken);
            return result.IP;
        }

        public async Task<HealthStatusResponse> GetHealthStatusAsync(CancellationToken cancellationToken = default)
        {
            return await MakeRequestAsync<HealthStatusResponse>("health", cancellationToken);
        }

        public async Task<ServiceStatsResponse> GetStatsAsync(CancellationToken cancellationToken = default)
        {
            return await MakeRequestAsync<ServiceStatsResponse>("stats", cancellationToken);
        }

        public async Task<IEnumerable<LookupResult>> LookupBatchAsync(IEnumerable<string> ips, TimeSpan delay, CancellationToken cancellationToken = default)
        {
            var results = new List<LookupResult>();
            var ipList = ips.ToList();

            for (int i = 0; i < ipList.Count; i++)
            {
                var ip = ipList[i];
                try
                {
                    var location = await LookupAsync(ip, cancellationToken);
                    results.Add(new LookupResult { IP = ip, Location = location });
                }
                catch (Exception ex)
                {
                    results.Add(new LookupResult { IP = ip, Error = ex });
                }

                // Add delay between requests (except for the last one)
                if (i < ipList.Count - 1)
                {
                    await Task.Delay(delay, cancellationToken);
                }
            }

            return results;
        }

        public async Task<IEnumerable<LookupResult>> LookupConcurrentAsync(IEnumerable<string> ips, int maxConcurrency = 5, CancellationToken cancellationToken = default)
        {
            var semaphore = new SemaphoreSlim(maxConcurrency, maxConcurrency);
            var tasks = ips.Select(async ip =>
            {
                await semaphore.WaitAsync(cancellationToken);
                try
                {
                    var location = await LookupAsync(ip, cancellationToken);
                    return new LookupResult { IP = ip, Location = location };
                }
                catch (Exception ex)
                {
                    return new LookupResult { IP = ip, Error = ex };
                }
                finally
                {
                    semaphore.Release();
                }
            });

            return await Task.WhenAll(tasks);
        }

        public void ClearCache()
        {
            if (_cache is MemoryCache memoryCache)
            {
                memoryCache.Compact(1.0); // Remove all items
            }
        }

        private async Task<T> MakeRequestAsync<T>(string endpoint, CancellationToken cancellationToken)
        {
            await _rateLimitSemaphore.WaitAsync(cancellationToken);
            try
            {
                return await MakeRequestWithRetryAsync<T>(endpoint, cancellationToken);
            }
            finally
            {
                // Release semaphore after a delay to respect rate limits
                _ = Task.Delay(TimeSpan.FromMilliseconds(500), cancellationToken)
                       .ContinueWith(_ => _rateLimitSemaphore.Release(), cancellationToken);
            }
        }

        private async Task<T> MakeRequestWithRetryAsync<T>(string endpoint, CancellationToken cancellationToken)
        {
            Exception? lastException = null;

            for (int attempt = 0; attempt <= _options.MaxRetries; attempt++)
            {
                try
                {
                    var response = await _httpClient.GetAsync(endpoint, cancellationToken);

                    if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        throw new IPGeoLocationException("Rate limit exceeded. Please wait before making more requests.", 429);
                    }

                    var content = await response.Content.ReadAsStringAsync(cancellationToken);

                    if (!response.IsSuccessStatusCode)
                    {
                        var errorResponse = JsonSerializer.Deserialize<APIErrorResponse>(content, _jsonOptions);
                        var errorMessage = errorResponse?.Error ?? $"HTTP {(int)response.StatusCode}: {response.ReasonPhrase}";
                        throw new IPGeoLocationException(errorMessage, (int)response.StatusCode);
                    }

                    var result = JsonSerializer.Deserialize<T>(content, _jsonOptions);
                    return result ?? throw new IPGeoLocationException("Failed to deserialize response");
                }
                catch (TaskCanceledException ex) when (ex.InnerException is TimeoutException)
                {
                    lastException = new IPGeoLocationException("Request timeout", ex);
                }
                catch (HttpRequestException ex)
                {
                    lastException = new IPGeoLocationException("HTTP request failed", ex);
                }
                catch (IPGeoLocationException)
                {
                    throw; // Don't retry API errors
                }
                catch (Exception ex)
                {
                    lastException = new IPGeoLocationException("Unexpected error", ex);
                }

                if (attempt < _options.MaxRetries)
                {
                    var delay = TimeSpan.FromMilliseconds(_options.RetryDelay.TotalMilliseconds * Math.Pow(2, attempt));
                    await Task.Delay(delay, cancellationToken);
                }
            }

            throw lastException ?? new IPGeoLocationException("Request failed after all retries");
        }

        public void Dispose()
        {
            if (!_disposed)
            {
                _rateLimitSemaphore?.Dispose();
                _cache?.Dispose();
                _disposed = true;
            }
        }
    }

    // Utility methods
    public static class IPGeoUtils
    {
        public static double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
        {
            const double earthRadius = 6371; // Earth's radius in kilometers

            var lat1Rad = lat1 * Math.PI / 180;
            var lat2Rad = lat2 * Math.PI / 180;
            var deltaLat = (lat2 - lat1) * Math.PI / 180;
            var deltaLon = (lon2 - lon1) * Math.PI / 180;

            var a = Math.Sin(deltaLat / 2) * Math.Sin(deltaLat / 2) +
                    Math.Cos(lat1Rad) * Math.Cos(lat2Rad) *
                    Math.Sin(deltaLon / 2) * Math.Sin(deltaLon / 2);

            var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            return earthRadius * c;
        }

        public static bool IsValidIP(string ip)
        {
            return System.Net.IPAddress.TryParse(ip, out _);
        }
    }

    // Example usage and demonstrations
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("=== IP Geolocation API Examples ===\n");

            // Create services
            var services = new ServiceCollection();
            services.AddMemoryCache();
            services.AddLogging(builder => builder.AddConsole());
            services.AddHttpClient<IIPGeoClient, IPGeoClient>();

            var serviceProvider = services.BuildServiceProvider();
            var client = serviceProvider.GetRequiredService<IIPGeoClient>();

            try
            {
                // Example 1: Get current IP location
                Console.WriteLine("1. Getting your current location...");
                var currentLocation = await client.LookupAsync();
                Console.WriteLine($"Your IP: {currentLocation.IP}");
                Console.WriteLine($"Location: {currentLocation}");
                Console.WriteLine($"Coordinates: {currentLocation.Latitude ?? 0:F4}, {currentLocation.Longitude ?? 0:F4}");
                Console.WriteLine($"ISP: {currentLocation.ISP ?? "Unknown"}");
                Console.WriteLine();

                // Example 2: Look up specific IPs
                var testIPs = new[] { "8.8.8.8", "1.1.1.1", "208.67.222.222" };
                
                Console.WriteLine("2. Looking up specific IP addresses...");
                foreach (var ip in testIPs)
                {
                    try
                    {
                        var location = await client.LookupAsync(ip);
                        Console.WriteLine($"{ip} -> {location} ({location.ISP ?? "Unknown ISP"})");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error looking up {ip}: {ex.Message}");
                    }
                }
                Console.WriteLine();

                // Example 3: Batch processing with rate limiting
                Console.WriteLine("3. Batch processing with rate limiting...");
                var batchIPs = new[] { "8.8.8.8", "1.1.1.1" };
                var batchResults = await client.LookupBatchAsync(batchIPs, TimeSpan.FromSeconds(1));

                foreach (var result in batchResults)
                {
                    if (result.IsSuccess)
                    {
                        Console.WriteLine($"{result.IP} -> {result.Location}");
                    }
                    else
                    {
                        Console.WriteLine($"{result.IP} -> Error: {result.Error?.Message}");
                    }
                }
                Console.WriteLine();

                // Example 4: Concurrent processing
                Console.WriteLine("4. Concurrent processing...");
                var concurrentIPs = new[] { "8.8.8.8", "1.1.1.1", "208.67.222.222", "9.9.9.9" };
                var concurrentResults = await client.LookupConcurrentAsync(concurrentIPs, 3);

                foreach (var result in concurrentResults)
                {
                    if (result.IsSuccess)
                    {
                        Console.WriteLine($"{result.IP} -> {result.Location}");
                    }
                    else
                    {
                        Console.WriteLine($"{result.IP} -> Error: {result.Error?.Message}");
                    }
                }
                Console.WriteLine();

                // Example 5: API health check
                Console.WriteLine("5. Checking API health...");
                var health = await client.GetHealthStatusAsync();
                Console.WriteLine($"API Status: {(health.OK ? "OK" : "DOWN")}");
                Console.WriteLine($"Database Age: {health.DbAge}");
                Console.WriteLine($"Uptime: {health.Uptime} seconds");
                Console.WriteLine();

                // Example 6: Service statistics
                Console.WriteLine("6. Getting service statistics...");
                var stats = await client.GetStatsAsync();
                Console.WriteLine($"Total Requests: {stats.TotalRequests}");
                Console.WriteLine($"Average Response Time: {stats.AvgResponseTime}");
                Console.WriteLine($"Uptime: {stats.Uptime}");
                Console.WriteLine();

                // Example 7: Distance calculation
                Console.WriteLine("7. Calculating distance between Google and Cloudflare DNS...");
                var googleDNS = await client.LookupAsync("8.8.8.8");
                var cloudflareDNS = await client.LookupAsync("1.1.1.1");

                if (googleDNS.Latitude.HasValue && googleDNS.Longitude.HasValue &&
                    cloudflareDNS.Latitude.HasValue && cloudflareDNS.Longitude.HasValue)
                {
                    var distance = IPGeoUtils.CalculateDistance(
                        googleDNS.Latitude.Value, googleDNS.Longitude.Value,
                        cloudflareDNS.Latitude.Value, cloudflareDNS.Longitude.Value
                    );

                    Console.WriteLine($"Distance: {distance:F2} km");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                client.ClearCache();
                serviceProvider.Dispose();
            }
        }
    }
}

/*
Usage Examples:

1. .NET Console Application:
   dotnet new console -n IPGeoExample
   cd IPGeoExample
   dotnet add package Microsoft.Extensions.DependencyInjection
   dotnet add package Microsoft.Extensions.Http
   dotnet add package Microsoft.Extensions.Caching.Memory
   dotnet add package Microsoft.Extensions.Logging.Console

2. ASP.NET Core Integration:
   
   // In Startup.cs or Program.cs
   builder.Services.AddMemoryCache();
   builder.Services.AddHttpClient<IIPGeoClient, IPGeoClient>();
   
   // In Controller
   [ApiController]
   [Route("api/[controller]")]
   public class GeoLocationController : ControllerBase
   {
       private readonly IIPGeoClient _geoClient;
   
       public GeoLocationController(IIPGeoClient geoClient)
       {
           _geoClient = geoClient;
       }
   
       [HttpGet]
       public async Task<ActionResult<IPLocationResponse>> Get()
       {
           try
           {
               var result = await _geoClient.LookupAsync();
               return Ok(result);
           }
           catch (IPGeoLocationException ex)
           {
               return BadRequest(new { error = ex.Message });
           }
       }
   
       [HttpGet("{ip}")]
       public async Task<ActionResult<IPLocationResponse>> Get(string ip)
       {
           try
           {
               var result = await _geoClient.LookupAsync(ip);
               return Ok(result);
           }
           catch (IPGeoLocationException ex)
           {
               return BadRequest(new { error = ex.Message });
           }
       }
   }

3. Blazor Component:
   
   @inject IIPGeoClient GeoClient
   
   <div>
       @if (location != null)
       {
           <p>Your location: @location</p>
           <p>ISP: @location.ISP</p>
       }
       else
       {
           <p>Loading...</p>
       }
   </div>
   
   @code {
       private IPLocationResponse? location;
   
       protected override async Task OnInitializedAsync()
       {
           try
           {
               location = await GeoClient.LookupAsync();
           }
           catch (Exception ex)
           {
               // Handle error
           }
       }
   }

4. Configuration with appsettings.json:
   
   {
     "IPGeoClient": {
       "BaseUrl": "https://your-custom-instance.com/api",
       "RequestTimeout": "00:00:30",
       "CacheTimeout": "00:15:00",
       "MaxRetries": 3,
       "RetryDelay": "00:00:01"
     }
   }

5. NuGet Package Creation:
   
   <Project Sdk="Microsoft.NET.Sdk">
     <PropertyGroup>
       <TargetFramework>net6.0</TargetFramework>
       <PackageId>YourName.IPGeoLocation.Client</PackageId>
       <PackageVersion>1.0.0</PackageVersion>
       <Authors>Your Name</Authors>
       <Description>C# client for Free IP Geolocation API</Description>
     </PropertyGroup>
   
     <ItemGroup>
       <PackageReference Include="Microsoft.Extensions.Caching.Memory" Version="6.0.0" />
       <PackageReference Include="Microsoft.Extensions.Http" Version="6.0.0" />
       <PackageReference Include="Microsoft.Extensions.Logging" Version="6.0.0" />
       <PackageReference Include="System.Text.Json" Version="6.0.0" />
     </ItemGroup>
   </Project>

Compilation:
dotnet build
dotnet run
*/