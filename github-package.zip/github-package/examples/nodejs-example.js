/**
 * Node.js Example for Free IP Geolocation API
 * 
 * This example demonstrates various ways to use the API with Node.js
 * including error handling, rate limiting, and caching.
 */

// Using built-in fetch (Node.js 18+)
const BASE_URL = 'https://ip-address.replit.app/api';

// Simple IP lookup
async function getIPLocation(ip) {
    try {
        const url = ip ? `${BASE_URL}/geo/${ip}` : `${BASE_URL}/geo`;
        const response = await fetch(url);
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(`API Error: ${error.error}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Failed to get IP location:', error.message);
        throw error;
    }
}

// Get current IP
async function getCurrentIP() {
    const response = await fetch(`${BASE_URL}/myip`);
    const data = await response.json();
    return data.ip;
}

// Example with error handling and retry logic
class IPGeoClient {
    constructor(options = {}) {
        this.baseURL = options.baseURL || BASE_URL;
        this.cache = new Map();
        this.cacheTimeout = options.cacheTimeout || 15 * 60 * 1000; // 15 minutes
    }
    
    async lookup(ip = null) {
        const cacheKey = ip || 'current';
        const cached = this.cache.get(cacheKey);
        
        // Return cached result if still valid
        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            console.log(`Using cached result for ${cacheKey}`);
            return cached.data;
        }
        
        try {
            const url = ip ? `${this.baseURL}/geo/${ip}` : `${this.baseURL}/geo`;
            const response = await fetch(url);
            
            if (response.status === 429) {
                throw new Error('Rate limit exceeded. Please wait before making more requests.');
            }
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(`API Error (${response.status}): ${error.error || error.message}`);
            }
            
            const data = await response.json();
            
            // Cache the result
            this.cache.set(cacheKey, {
                data,
                timestamp: Date.now()
            });
            
            return data;
            
        } catch (error) {
            console.error(`Failed to lookup IP ${ip || 'current'}:`, error.message);
            throw error;
        }
    }
    
    async getCurrentIP() {
        const response = await fetch(`${this.baseURL}/myip`);
        if (!response.ok) {
            throw new Error(`Failed to get current IP: ${response.statusText}`);
        }
        const data = await response.json();
        return data.ip;
    }
    
    async getHealthStatus() {
        const response = await fetch(`${this.baseURL}/health`);
        return await response.json();
    }
    
    async getStats() {
        const response = await fetch(`${this.baseURL}/stats`);
        return await response.json();
    }
    
    // Rate-limited batch processing
    async lookupBatch(ips, delayMs = 500) {
        const results = [];
        
        for (const ip of ips) {
            try {
                const result = await this.lookup(ip);
                results.push({ ip, ...result });
                
                // Add delay to respect rate limits
                if (ips.indexOf(ip) < ips.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, delayMs));
                }
            } catch (error) {
                results.push({ ip, error: error.message });
            }
        }
        
        return results;
    }
    
    clearCache() {
        this.cache.clear();
    }
}

// Usage examples
async function examples() {
    console.log('=== IP Geolocation API Examples ===\n');
    
    // Create client instance
    const client = new IPGeoClient();
    
    // Example 1: Get current IP location
    try {
        console.log('1. Getting your current location...');
        const currentLocation = await client.lookup();
        console.log(`Your IP: ${currentLocation.ip}`);
        console.log(`Location: ${currentLocation.city}, ${currentLocation.region}, ${currentLocation.country}`);
        console.log(`Coordinates: ${currentLocation.latitude}, ${currentLocation.longitude}`);
        console.log(`ISP: ${currentLocation.isp}\n`);
    } catch (error) {
        console.error('Error getting current location:', error.message);
    }
    
    // Example 2: Look up specific IPs
    const testIPs = ['8.8.8.8', '1.1.1.1', '208.67.222.222'];
    
    console.log('2. Looking up specific IP addresses...');
    for (const ip of testIPs) {
        try {
            const location = await client.lookup(ip);
            console.log(`${ip} -> ${location.city}, ${location.country} (${location.isp})`);
        } catch (error) {
            console.error(`Error looking up ${ip}:`, error.message);
        }
    }
    
    // Example 3: Batch processing with rate limiting
    console.log('\n3. Batch processing with rate limiting...');
    try {
        const batchResults = await client.lookupBatch(['8.8.8.8', '1.1.1.1'], 1000);
        batchResults.forEach(result => {
            if (result.error) {
                console.log(`${result.ip} -> Error: ${result.error}`);
            } else {
                console.log(`${result.ip} -> ${result.city}, ${result.country}`);
            }
        });
    } catch (error) {
        console.error('Batch processing error:', error.message);
    }
    
    // Example 4: API health check
    console.log('\n4. Checking API health...');
    try {
        const health = await client.getHealthStatus();
        console.log(`API Status: ${health.ok ? 'OK' : 'DOWN'}`);
        console.log(`Database Age: ${health.dbAge}`);
        console.log(`Uptime: ${health.uptime} seconds`);
    } catch (error) {
        console.error('Health check failed:', error.message);
    }
    
    // Example 5: Service statistics
    console.log('\n5. Getting service statistics...');
    try {
        const stats = await client.getStats();
        console.log(`Total Requests: ${stats.totalRequests}`);
        console.log(`Average Response Time: ${stats.avgResponseTime}`);
        console.log(`Uptime: ${stats.uptime}`);
    } catch (error) {
        console.error('Stats retrieval failed:', error.message);
    }
}

// Run examples if this file is executed directly
if (require.main === module) {
    examples().catch(console.error);
}

// Export for use as a module
module.exports = {
    IPGeoClient,
    getIPLocation,
    getCurrentIP
};

/*
Installation and Usage:

1. Save this file as ip-geo-example.js
2. Run with Node.js 18+ (for built-in fetch support):
   node ip-geo-example.js

For older Node.js versions, install node-fetch:
npm install node-fetch

Then add at the top:
const fetch = require('node-fetch');

Advanced Usage:

// Create client with custom options
const client = new IPGeoClient({
    baseURL: 'https://your-custom-instance.com/api',
    cacheTimeout: 30 * 60 * 1000 // 30 minutes cache
});

// Use with async/await
const location = await client.lookup('8.8.8.8');

// Use with promises
client.lookup('8.8.8.8')
    .then(location => console.log(location))
    .catch(error => console.error(error));

// Bulk processing with custom delay
const results = await client.lookupBatch(['8.8.8.8', '1.1.1.1'], 2000);
*/