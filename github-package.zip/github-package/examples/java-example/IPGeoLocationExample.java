/**
 * Java Example for Free IP Geolocation API
 * 
 * This example demonstrates how to use the API with Java using
 * the modern java.net.http.HttpClient (Java 11+).
 * 
 * Features:
 * - HTTP client with timeout and error handling
 * - JSON parsing using Jackson or Gson
 * - Caching with configurable timeout
 * - Batch processing with rate limiting
 * - Retry logic for failed requests
 */

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class IPGeoLocationExample {
    
    private static final String BASE_URL = "https://ip-address.replit.app/api";
    
    // Data classes for JSON mapping
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class IPLocation {
        public String ip;
        public String countryCode;
        public String country;
        public String regionCode;
        public String region;
        public String city;
        public String postalCode;
        public Double latitude;
        public Double longitude;
        public String timezone;
        public String isp;
        public Integer asn;
        
        @Override
        public String toString() {
            return String.format("IPLocation{ip='%s', city='%s', region='%s', country='%s', isp='%s'}",
                ip, city, region, country, isp);
        }
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CurrentIP {
        public String ip;
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class HealthStatus {
        public Boolean ok;
        public String dbAge;
        public Integer uptime;
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ServiceStats {
        public String totalRequests;
        public String avgResponseTime;
        public String uptime;
        public String cacheHitRate;
    }
    
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ErrorResponse {
        public String error;
        public Integer code;
        public String message;
    }
    
    // Cache entry class
    private static class CacheEntry<T> {
        public final T data;
        public final Instant timestamp;
        
        public CacheEntry(T data) {
            this.data = data;
            this.timestamp = Instant.now();
        }
        
        public boolean isExpired(Duration maxAge) {
            return Instant.now().isAfter(timestamp.plus(maxAge));
        }
    }
    
    /**
     * Main IP Geolocation client class
     */
    public static class IPGeoClient {
        private final HttpClient httpClient;
        private final ObjectMapper objectMapper;
        private final String baseUrl;
        private final Duration cacheTimeout;
        private final Map<String, CacheEntry<?>> cache;
        
        public IPGeoClient() {
            this(BASE_URL, Duration.ofMinutes(15));
        }
        
        public IPGeoClient(String baseUrl, Duration cacheTimeout) {
            this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
            this.cacheTimeout = cacheTimeout;
            this.objectMapper = new ObjectMapper();
            this.cache = new ConcurrentHashMap<>();
            
            this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        }
        
        /**
         * Make HTTP GET request with error handling
         */
        private <T> T makeRequest(String endpoint, Class<T> responseType) throws Exception {
            String url = baseUrl + (endpoint.startsWith("/") ? endpoint : "/" + endpoint);
            
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .header("User-Agent", "Java-IPGeoClient/1.0")
                .timeout(Duration.ofSeconds(30))
                .GET()
                .build();
            
            HttpResponse<String> response = httpClient.send(request, 
                HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() == 429) {
                throw new RuntimeException("Rate limit exceeded. Please wait before making more requests.");
            }
            
            if (response.statusCode() >= 400) {
                try {
                    ErrorResponse error = objectMapper.readValue(response.body(), ErrorResponse.class);
                    throw new RuntimeException(String.format("HTTP %d: %s", 
                        response.statusCode(), error.error != null ? error.error : "Unknown error"));
                } catch (Exception e) {
                    throw new RuntimeException(String.format("HTTP %d: %s", 
                        response.statusCode(), response.body()));
                }
            }
            
            return objectMapper.readValue(response.body(), responseType);
        }
        
        /**
         * Get cached result or null if not found/expired
         */
        @SuppressWarnings("unchecked")
        private <T> T getCachedResult(String key, Class<T> type) {
            CacheEntry<?> entry = cache.get(key);
            if (entry != null && !entry.isExpired(cacheTimeout)) {
                System.out.println("Using cached result for " + key);
                return (T) entry.data;
            }
            return null;
        }
        
        /**
         * Cache a result
         */
        private <T> void cacheResult(String key, T data) {
            cache.put(key, new CacheEntry<>(data));
        }
        
        /**
         * Look up IP geolocation information
         * 
         * @param ip IP address to lookup (null for current IP)
         * @return IPLocation object with geolocation data
         */
        public IPLocation lookup(String ip) throws Exception {
            String cacheKey = ip != null ? ip : "current";
            
            // Check cache first
            IPLocation cached = getCachedResult(cacheKey, IPLocation.class);
            if (cached != null) {
                return cached;
            }
            
            // Make API request
            String endpoint = ip != null ? "/geo/" + ip : "/geo";
            IPLocation result = makeRequest(endpoint, IPLocation.class);
            
            // Cache the result
            cacheResult(cacheKey, result);
            
            return result;
        }
        
        /**
         * Get current IP address
         */
        public String getCurrentIP() throws Exception {
            CurrentIP result = makeRequest("/myip", CurrentIP.class);
            return result.ip;
        }
        
        /**
         * Get API health status
         */
        public HealthStatus getHealthStatus() throws Exception {
            return makeRequest("/health", HealthStatus.class);
        }
        
        /**
         * Get service statistics
         */
        public ServiceStats getStats() throws Exception {
            return makeRequest("/stats", ServiceStats.class);
        }
        
        /**
         * Look up multiple IPs with rate limiting
         * 
         * @param ips List of IP addresses to lookup
         * @param delayMs Delay between requests in milliseconds
         * @return List of lookup results
         */
        public List<Map<String, Object>> lookupBatch(List<String> ips, long delayMs) {
            List<Map<String, Object>> results = new ArrayList<>();
            
            for (int i = 0; i < ips.size(); i++) {
                String ip = ips.get(i);
                Map<String, Object> result = new HashMap<>();
                result.put("ip", ip);
                
                try {
                    IPLocation location = lookup(ip);
                    result.put("countryCode", location.countryCode);
                    result.put("country", location.country);
                    result.put("region", location.region);
                    result.put("city", location.city);
                    result.put("isp", location.isp);
                    result.put("latitude", location.latitude);
                    result.put("longitude", location.longitude);
                } catch (Exception e) {
                    result.put("error", e.getMessage());
                }
                
                results.add(result);
                
                // Add delay between requests (except for the last one)
                if (i < ips.size() - 1) {
                    try {
                        Thread.sleep(delayMs);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
            
            return results;
        }
        
        /**
         * Clear the cache
         */
        public void clearCache() {
            cache.clear();
        }
        
        /**
         * Close the HTTP client
         */
        public void close() {
            // HttpClient doesn't need explicit closing in Java 11+
            cache.clear();
        }
    }
    
    // Utility methods
    public static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final double R = 6371; // Earth's radius in kilometers
        
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        
        return R * c;
    }
    
    public static String formatLocation(IPLocation location) {
        List<String> parts = new ArrayList<>();
        
        if (location.city != null && !location.city.isEmpty()) {
            parts.add(location.city);
        }
        if (location.region != null && !location.region.isEmpty()) {
            parts.add(location.region);
        }
        if (location.country != null && !location.country.isEmpty()) {
            parts.add(location.country);
        }
        
        return parts.isEmpty() ? "Unknown location" : String.join(", ", parts);
    }
    
    // Main method with examples
    public static void main(String[] args) {
        System.out.println("=== IP Geolocation API Examples ===\n");
        
        IPGeoClient client = new IPGeoClient();
        
        try {
            // Example 1: Get current IP location
            System.out.println("1. Getting your current location...");
            IPLocation currentLocation = client.lookup(null);
            System.out.println("Your IP: " + currentLocation.ip);
            System.out.println("Location: " + formatLocation(currentLocation));
            System.out.println("Coordinates: " + currentLocation.latitude + ", " + currentLocation.longitude);
            System.out.println("ISP: " + currentLocation.isp);
            System.out.println();
            
            // Example 2: Look up specific IPs
            String[] testIPs = {"8.8.8.8", "1.1.1.1", "208.67.222.222"};
            
            System.out.println("2. Looking up specific IP addresses...");
            for (String ip : testIPs) {
                try {
                    IPLocation location = client.lookup(ip);
                    System.out.println(ip + " -> " + formatLocation(location) + 
                        " (" + location.isp + ")");
                } catch (Exception e) {
                    System.out.println("Error looking up " + ip + ": " + e.getMessage());
                }
            }
            System.out.println();
            
            // Example 3: Batch processing with rate limiting
            System.out.println("3. Batch processing with rate limiting...");
            List<String> batchIPs = Arrays.asList("8.8.8.8", "1.1.1.1");
            List<Map<String, Object>> batchResults = client.lookupBatch(batchIPs, 1000);
            
            for (Map<String, Object> result : batchResults) {
                String ip = (String) result.get("ip");
                if (result.containsKey("error")) {
                    System.out.println(ip + " -> Error: " + result.get("error"));
                } else {
                    System.out.println(ip + " -> " + result.get("city") + ", " + result.get("country"));
                }
            }
            System.out.println();
            
            // Example 4: API health check
            System.out.println("4. Checking API health...");
            HealthStatus health = client.getHealthStatus();
            System.out.println("API Status: " + (health.ok ? "OK" : "DOWN"));
            System.out.println("Database Age: " + health.dbAge);
            System.out.println("Uptime: " + health.uptime + " seconds");
            System.out.println();
            
            // Example 5: Service statistics
            System.out.println("5. Getting service statistics...");
            ServiceStats stats = client.getStats();
            System.out.println("Total Requests: " + stats.totalRequests);
            System.out.println("Average Response Time: " + stats.avgResponseTime);
            System.out.println("Uptime: " + stats.uptime);
            System.out.println();
            
            // Example 6: Calculate distance between two IPs
            System.out.println("6. Calculating distance between Google and Cloudflare DNS...");
            IPLocation googleDNS = client.lookup("8.8.8.8");
            IPLocation cloudflareDNS = client.lookup("1.1.1.1");
            
            if (googleDNS.latitude != null && googleDNS.longitude != null &&
                cloudflareDNS.latitude != null && cloudflareDNS.longitude != null) {
                
                double distance = calculateDistance(
                    googleDNS.latitude, googleDNS.longitude,
                    cloudflareDNS.latitude, cloudflareDNS.longitude
                );
                
                System.out.println("Distance between Google DNS and Cloudflare DNS: " + 
                    String.format("%.2f km", distance));
            }
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            client.close();
        }
    }
}

/*
Compilation and Usage:

1. Add Jackson dependency to your project (Maven):
   <dependency>
       <groupId>com.fasterxml.jackson.core</groupId>
       <artifactId>jackson-databind</artifactId>
       <version>2.15.2</version>
   </dependency>

   Or Gradle:
   implementation 'com.fasterxml.jackson.core:jackson-databind:2.15.2'

2. Compile and run:
   javac -cp ".:jackson-databind-2.15.2.jar:jackson-core-2.15.2.jar:jackson-annotations-2.15.2.jar" IPGeoLocationExample.java
   java -cp ".:jackson-databind-2.15.2.jar:jackson-core-2.15.2.jar:jackson-annotations-2.15.2.jar" IPGeoLocationExample

Alternative with Gson (Google's JSON library):

Replace Jackson with Gson:
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.10.1</version>
</dependency>

Then replace ObjectMapper usage with Gson:
private final Gson gson = new Gson();
// Instead of: objectMapper.readValue(response.body(), responseType)
// Use: gson.fromJson(response.body(), responseType)

Spring Boot Example:

@RestController
@RequestMapping("/api/geo-lookup")
public class GeoLookupController {
    
    private final IPGeoClient ipGeoClient;
    
    public GeoLookupController() {
        this.ipGeoClient = new IPGeoClient();
    }
    
    @GetMapping("/current")
    public IPLocation getCurrentLocation(HttpServletRequest request) throws Exception {
        String clientIP = getClientIP(request);
        return ipGeoClient.lookup(clientIP);
    }
    
    @GetMapping("/{ip}")
    public IPLocation lookupIP(@PathVariable String ip) throws Exception {
        return ipGeoClient.lookup(ip);
    }
    
    private String getClientIP(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
            return xForwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
*/