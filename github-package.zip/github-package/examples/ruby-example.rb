#!/usr/bin/env ruby
# frozen_string_literal: true

=begin
Ruby Example for Free IP Geolocation API

This example demonstrates various ways to use the API with Ruby
including error handling, caching, rate limiting, and batch processing.

Requirements:
- Ruby 2.7+
- net/http (standard library)
- json (standard library)

Optional gems:
gem install httparty  # For easier HTTP requests
gem install redis     # For Redis caching
=end

require 'net/http'
require 'json'
require 'uri'
require 'time'

# Optional gems (uncomment if available)
# require 'httparty'
# require 'redis'

# API Configuration
API_BASE_URL = 'https://ip-address.replit.app/api'
CACHE_TIMEOUT = 900 # 15 minutes in seconds

##
# Main IP Geolocation client class
class IPGeoClient
  attr_reader :base_url, :cache_timeout

  def initialize(base_url = API_BASE_URL, cache_timeout = CACHE_TIMEOUT)
    @base_url = base_url.chomp('/')
    @cache_timeout = cache_timeout
    @cache = {}
    @http_timeout = 30
  end

  ##
  # Look up IP geolocation information
  #
  # @param ip [String, nil] IP address to lookup (nil for current IP)
  # @return [Hash] Geolocation data
  def lookup(ip = nil)
    cache_key = ip || 'current'

    # Check cache first
    if cache_valid?(cache_key)
      puts "Using cached result for #{cache_key}"
      return @cache[cache_key][:data]
    end

    # Make API request
    endpoint = ip ? "/geo/#{ip}" : '/geo'
    data = make_request(endpoint)

    # Cache the result
    cache_result(cache_key, data)

    data
  end

  ##
  # Get current IP address
  #
  # @return [String] Current IP address
  def current_ip
    data = make_request('/myip')
    data['ip']
  end

  ##
  # Get API health status
  #
  # @return [Hash] Health status information
  def health_status
    make_request('/health')
  end

  ##
  # Get service statistics
  #
  # @return [Hash] Service statistics
  def stats
    make_request('/stats')
  end

  ##
  # Look up multiple IPs with rate limiting
  #
  # @param ips [Array<String>] Array of IP addresses
  # @param delay_seconds [Float] Delay between requests in seconds
  # @return [Array<Hash>] Array of lookup results
  def lookup_batch(ips, delay_seconds = 0.5)
    results = []

    ips.each_with_index do |ip, index|
      begin
        location = lookup(ip)
        results << location.merge('ip' => ip)
      rescue StandardError => e
        results << { 'ip' => ip, 'error' => e.message }
      end

      # Add delay between requests (except for the last one)
      sleep(delay_seconds) if index < ips.length - 1
    end

    results
  end

  ##
  # Look up multiple IPs concurrently using threads
  #
  # @param ips [Array<String>] Array of IP addresses
  # @param max_threads [Integer] Maximum number of concurrent threads
  # @return [Array<Hash>] Array of lookup results
  def lookup_concurrent(ips, max_threads = 5)
    results = []
    mutex = Mutex.new

    # Process IPs in batches
    ips.each_slice(max_threads) do |ip_batch|
      threads = []

      ip_batch.each do |ip|
        threads << Thread.new do
          begin
            location = lookup(ip)
            result = location.merge('ip' => ip)
          rescue StandardError => e
            result = { 'ip' => ip, 'error' => e.message }
          end

          mutex.synchronize { results << result }
        end
      end

      threads.each(&:join)
    end

    results
  end

  ##
  # Clear the cache
  def clear_cache
    @cache.clear
  end

  private

  ##
  # Make HTTP GET request with error handling
  #
  # @param endpoint [String] API endpoint
  # @return [Hash] Parsed JSON response
  def make_request(endpoint)
    url = URI("#{@base_url}/#{endpoint.sub(/^\//, '')}")

    http = Net::HTTP.new(url.host, url.port)
    http.use_ssl = url.scheme == 'https'
    http.read_timeout = @http_timeout
    http.open_timeout = @http_timeout

    request = Net::HTTP::Get.new(url)
    request['Accept'] = 'application/json'
    request['User-Agent'] = 'Ruby-IPGeoClient/1.0'

    response = http.request(request)

    case response.code.to_i
    when 200
      JSON.parse(response.body)
    when 429
      raise StandardError, 'Rate limit exceeded. Please wait before making more requests.'
    when 400..499
      error_data = JSON.parse(response.body) rescue {}
      error_message = error_data['error'] || "HTTP #{response.code}: Client error"
      raise StandardError, error_message
    when 500..599
      raise StandardError, "HTTP #{response.code}: Server error"
    else
      raise StandardError, "HTTP #{response.code}: #{response.message}"
    end
  rescue JSON::ParserError => e
    raise StandardError, "Invalid JSON response: #{e.message}"
  rescue Net::TimeoutError => e
    raise StandardError, "Request timeout: #{e.message}"
  rescue StandardError => e
    raise e
  end

  ##
  # Check if cached data is still valid
  #
  # @param key [String] Cache key
  # @return [Boolean] True if cache is valid
  def cache_valid?(key)
    return false unless @cache[key]

    Time.now - @cache[key][:timestamp] < @cache_timeout
  end

  ##
  # Cache API result
  #
  # @param key [String] Cache key
  # @param data [Hash] Data to cache
  def cache_result(key, data)
    @cache[key] = {
      data: data,
      timestamp: Time.now
    }
  end
end

##
# Simple function-based interface
module IPGeoLocation
  module_function

  ##
  # Get IP geolocation information
  #
  # @param ip [String, nil] IP address to lookup
  # @return [Hash] Geolocation data
  def lookup(ip = nil)
    url = "#{API_BASE_URL}/geo"
    url += "/#{ip}" if ip

    uri = URI(url)
    response = Net::HTTP.get_response(uri)

    raise StandardError, "HTTP #{response.code}: #{response.message}" unless response.is_a?(Net::HTTPSuccess)

    JSON.parse(response.body)
  end

  ##
  # Get current IP address
  #
  # @return [String] Current IP address
  def current_ip
    response = lookup
    response['ip']
  end
end

##
# Utility methods
module IPGeoUtils
  module_function

  ##
  # Validate IP address format
  #
  # @param ip [String] IP address to validate
  # @return [Boolean] True if IP format is valid
  def valid_ip?(ip)
    # IPv4 pattern
    ipv4_pattern = /\A(\d{1,3}\.){3}\d{1,3}\z/

    # IPv6 pattern (simplified)
    ipv6_pattern = /\A[0-9a-fA-F:]+\z/

    !!(ip =~ ipv4_pattern || ip =~ ipv6_pattern)
  end

  ##
  # Format location data into readable string
  #
  # @param location_data [Hash] Location data from API
  # @return [String] Formatted location string
  def format_location(location_data)
    parts = []

    parts << location_data['city'] if location_data['city'] && !location_data['city'].empty?
    parts << location_data['region'] if location_data['region'] && !location_data['region'].empty?
    parts << location_data['country'] if location_data['country'] && !location_data['country'].empty?

    parts.empty? ? 'Unknown location' : parts.join(', ')
  end

  ##
  # Calculate distance between two coordinates using Haversine formula
  #
  # @param lat1 [Float] First latitude
  # @param lon1 [Float] First longitude
  # @param lat2 [Float] Second latitude
  # @param lon2 [Float] Second longitude
  # @return [Float] Distance in kilometers
  def calculate_distance(lat1, lon1, lat2, lon2)
    earth_radius = 6371 # Earth's radius in kilometers

    lat1_rad = lat1 * Math::PI / 180
    lat2_rad = lat2 * Math::PI / 180
    delta_lat = (lat2 - lat1) * Math::PI / 180
    delta_lon = (lon2 - lon1) * Math::PI / 180

    a = Math.sin(delta_lat / 2) * Math.sin(delta_lat / 2) +
        Math.cos(lat1_rad) * Math.cos(lat2_rad) *
        Math.sin(delta_lon / 2) * Math.sin(delta_lon / 2)

    c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

    earth_radius * c
  end
end

##
# Example usage and demonstrations
def run_examples
  puts '=== IP Geolocation API Examples ==='
  puts

  # Create client instance
  client = IPGeoClient.new

  # Example 1: Get current IP location
  begin
    puts '1. Getting your current location...'
    current_location = client.lookup
    puts "Your IP: #{current_location['ip']}"
    puts "Location: #{IPGeoUtils.format_location(current_location)}"
    puts "Coordinates: #{current_location['latitude'] || 'N/A'}, #{current_location['longitude'] || 'N/A'}"
    puts "ISP: #{current_location['isp'] || 'Unknown'}"
    puts
  rescue StandardError => e
    puts "Error getting current location: #{e.message}"
    puts
  end

  # Example 2: Look up specific IPs
  test_ips = %w[8.8.8.8 1.1.1.1 208.67.222.222]

  puts '2. Looking up specific IP addresses...'
  test_ips.each do |ip|
    begin
      location = client.lookup(ip)
      puts "#{ip} -> #{IPGeoUtils.format_location(location)} (#{location['isp'] || 'Unknown ISP'})"
    rescue StandardError => e
      puts "Error looking up #{ip}: #{e.message}"
    end
  end
  puts

  # Example 3: Batch processing with rate limiting
  puts '3. Batch processing with rate limiting...'
  begin
    batch_results = client.lookup_batch(%w[8.8.8.8 1.1.1.1], 1.0)
    batch_results.each do |result|
      if result['error']
        puts "#{result['ip']} -> Error: #{result['error']}"
      else
        puts "#{result['ip']} -> #{result['city'] || 'Unknown'}, #{result['country']}"
      end
    end
  rescue StandardError => e
    puts "Batch processing error: #{e.message}"
  end
  puts

  # Example 4: Concurrent processing
  puts '4. Concurrent processing...'
  begin
    concurrent_ips = %w[8.8.8.8 1.1.1.1 208.67.222.222 9.9.9.9]
    concurrent_results = client.lookup_concurrent(concurrent_ips, 3)
    concurrent_results.each do |result|
      if result['error']
        puts "#{result['ip']} -> Error: #{result['error']}"
      else
        puts "#{result['ip']} -> #{IPGeoUtils.format_location(result)}"
      end
    end
  rescue StandardError => e
    puts "Concurrent processing error: #{e.message}"
  end
  puts

  # Example 5: API health check
  puts '5. Checking API health...'
  begin
    health = client.health_status
    status = health['ok'] ? 'OK' : 'DOWN'
    puts "API Status: #{status}"
    puts "Database Age: #{health['dbAge']}"
    puts "Uptime: #{health['uptime']} seconds"
  rescue StandardError => e
    puts "Health check failed: #{e.message}"
  end
  puts

  # Example 6: Service statistics
  puts '6. Getting service statistics...'
  begin
    stats = client.stats
    puts "Total Requests: #{stats['totalRequests']}"
    puts "Average Response Time: #{stats['avgResponseTime']}"
    puts "Uptime: #{stats['uptime']}"
  rescue StandardError => e
    puts "Stats retrieval failed: #{e.message}"
  end
  puts

  # Example 7: Using simple function interface
  puts '7. Using simple function interface...'
  begin
    location = IPGeoLocation.lookup('8.8.8.8')
    puts "Google DNS is located in: #{IPGeoUtils.format_location(location)}"

    my_ip = IPGeoLocation.current_ip
    puts "Your IP address is: #{my_ip}"
  rescue StandardError => e
    puts "Simple interface error: #{e.message}"
  end
  puts

  # Example 8: Distance calculation
  puts '8. Calculating distance between two locations...'
  begin
    google_dns = client.lookup('8.8.8.8')
    cloudflare_dns = client.lookup('1.1.1.1')

    if google_dns['latitude'] && google_dns['longitude'] &&
       cloudflare_dns['latitude'] && cloudflare_dns['longitude']

      distance = IPGeoUtils.calculate_distance(
        google_dns['latitude'], google_dns['longitude'],
        cloudflare_dns['latitude'], cloudflare_dns['longitude']
      )

      puts "Distance between Google DNS and Cloudflare DNS: #{distance.round(2)} km"
    end
  rescue StandardError => e
    puts "Distance calculation error: #{e.message}"
  end
end

# HTTParty alternative implementation (if gem is available)
begin
  require 'httparty'

  ##
  # Alternative client using HTTParty gem
  class HTTPartyIPGeoClient
    include HTTParty
    base_uri API_BASE_URL
    default_timeout 30
    headers 'Accept' => 'application/json', 'User-Agent' => 'Ruby-HTTPartyClient/1.0'

    def self.lookup(ip = nil)
      endpoint = ip ? "/geo/#{ip}" : '/geo'
      response = get(endpoint)

      case response.code
      when 200
        response.parsed_response
      when 429
        raise StandardError, 'Rate limit exceeded. Please wait before making more requests.'
      else
        error = response.parsed_response
        raise StandardError, error['error'] || "HTTP #{response.code}: #{response.message}"
      end
    end
  end

  puts 'HTTParty gem detected - alternative client available'
rescue LoadError
  # HTTParty not available, use standard client
end

# Redis caching implementation (if gem is available)
begin
  require 'redis'

  ##
  # Client with Redis caching
  class RedisIPGeoClient < IPGeoClient
    def initialize(base_url = API_BASE_URL, cache_timeout = CACHE_TIMEOUT, redis_url = nil)
      super(base_url, cache_timeout)
      @redis = Redis.new(url: redis_url || ENV['REDIS_URL'] || 'redis://localhost:6379')
    end

    private

    def cache_valid?(key)
      @redis.exists?(cache_key(key)) > 0
    end

    def cache_result(key, data)
      @redis.setex(cache_key(key), @cache_timeout, data.to_json)
    end

    def cached_result(key)
      cached = @redis.get(cache_key(key))
      cached ? JSON.parse(cached) : nil
    end

    def cache_key(key)
      "ip_geo:#{key}"
    end

    def lookup(ip = nil)
      cache_key = ip || 'current'

      # Check Redis cache first
      if cache_valid?(cache_key)
        puts "Using Redis cached result for #{cache_key}"
        return cached_result(cache_key)
      end

      # Make API request
      endpoint = ip ? "/geo/#{ip}" : '/geo'
      data = make_request(endpoint)

      # Cache the result in Redis
      cache_result(cache_key, data)

      data
    end
  end

  puts 'Redis gem detected - Redis caching client available'
rescue LoadError
  # Redis not available, use memory caching
end

# Sinatra web app example (if gem is available)
begin
  require 'sinatra/base'

  ##
  # Sinatra web application
  class IPGeoApp < Sinatra::Base
    set :port, 4567

    before do
      content_type :json
      @client = IPGeoClient.new
    end

    get '/geo' do
      begin
        location = @client.lookup
        location.to_json
      rescue StandardError => e
        status 400
        { error: e.message }.to_json
      end
    end

    get '/geo/:ip' do
      begin
        ip = params[:ip]
        location = @client.lookup(ip)
        location.to_json
      rescue StandardError => e
        status 400
        { error: e.message }.to_json
      end
    end

    get '/health' do
      begin
        health = @client.health_status
        health.to_json
      rescue StandardError => e
        status 500
        { error: e.message }.to_json
      end
    end
  end

  puts 'Sinatra gem detected - Web app available'
rescue LoadError
  # Sinatra not available
end

# Rails integration example
module RailsIntegration
  ##
  # Rails controller example
  class GeoLocationController
    def lookup
      ip = params[:ip]

      begin
        client = IPGeoClient.new
        location = client.lookup(ip)
        render json: location
      rescue StandardError => e
        render json: { error: e.message }, status: :bad_request
      end
    end

    def current
      begin
        client = IPGeoClient.new
        location = client.lookup
        render json: location
      rescue StandardError => e
        render json: { error: e.message }, status: :bad_request
      end
    end
  end

  ##
  # Rails model example
  class IPLocation
    include ActiveModel::Model

    attr_accessor :ip, :country, :city, :region, :isp, :latitude, :longitude

    def self.find_by_ip(ip)
      client = IPGeoClient.new
      data = client.lookup(ip)

      new(
        ip: data['ip'],
        country: data['country'],
        city: data['city'],
        region: data['region'],
        isp: data['isp'],
        latitude: data['latitude'],
        longitude: data['longitude']
      )
    rescue StandardError
      nil
    end

    def to_s
      IPGeoUtils.format_location(attributes)
    end
  end
end

# Run examples if script is executed directly
run_examples if __FILE__ == $PROGRAM_NAME

=begin
Usage Examples:

1. Command Line:
   ruby ip-geo-example.rb

2. Interactive Ruby (IRB):
   irb
   load 'ip-geo-example.rb'
   client = IPGeoClient.new
   location = client.lookup('8.8.8.8')

3. Gemfile (for Rails/Sinatra projects):
   gem 'httparty'  # Optional
   gem 'redis'     # Optional
   gem 'sinatra'   # Optional

4. Rails Integration:
   # In config/routes.rb
   get '/geo', to: 'geo_location#current'
   get '/geo/:ip', to: 'geo_location#lookup'

   # In app/controllers/geo_location_controller.rb
   class GeoLocationController < ApplicationController
     include RailsIntegration::GeoLocationController
   end

5. Sinatra App:
   ruby ip-geo-example.rb
   # Then visit http://localhost:4567/geo

6. With Redis Caching:
   # Set REDIS_URL environment variable
   export REDIS_URL=redis://localhost:6379
   
   client = RedisIPGeoClient.new
   location = client.lookup('8.8.8.8')

Installation:
gem install httparty  # Optional
gem install redis     # Optional for caching
gem install sinatra   # Optional for web app

Basic usage:
client = IPGeoClient.new
location = client.lookup('8.8.8.8')
puts location['city']
=end