# Installation Guide

Complete guide to install and run your own instance of the Free IP Geolocation Service.

## Prerequisites

- **Node.js**: Version 18 or higher
- **PostgreSQL**: Version 13 or higher (optional, for session storage)
- **MaxMind Account**: Free account for GeoLite2 database
- **Git**: For cloning the repository

## Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/ip-geolocation-service.git
cd ip-geolocation-service
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Environment Configuration

Create a `.env` file in the root directory:

```env
# Required: MaxMind Configuration
MAXMIND_ACCOUNT_ID=your_account_id
MAXMIND_LICENSE_KEY=your_license_key

# Optional: Database Configuration (for session storage)
DATABASE_URL=postgresql://username:password@localhost:5432/ip_geolocation

# Optional: Server Configuration
PORT=5000
NODE_ENV=production

# Optional: Security Configuration
SESSION_SECRET=your_random_session_secret_here
RATE_LIMIT_WINDOW=60000
RATE_LIMIT_MAX=120
```

### 4. Get MaxMind Credentials

1. Sign up for a free MaxMind account at [maxmind.com](https://www.maxmind.com/en/geolite2/signup)
2. Go to "My License Key" in your account
3. Generate a new license key
4. Note your Account ID and License Key
5. Add them to your `.env` file

### 5. Database Setup (Optional)

If you want to use PostgreSQL for session storage:

```bash
# Create database
createdb ip_geolocation

# Run migrations (if any)
npm run db:push
```

### 6. Download GeoLite2 Database

The application will automatically download the MaxMind GeoLite2 database on first run. You can also manually download it:

```bash
npm run download-database
```

### 7. Build and Start

```bash
# Build the application
npm run build

# Start the server
npm start
```

The service will be available at `http://localhost:5000`

## Development Setup

For development with hot reloading:

```bash
# Install development dependencies
npm install

# Start in development mode
npm run dev
```

## Docker Installation

### Using Docker Compose (Recommended)

1. Clone the repository
2. Create `.env` file with your configuration
3. Run with Docker Compose:

```bash
docker-compose up -d
```

### Using Dockerfile

```bash
# Build the image
docker build -t ip-geolocation-service .

# Run the container
docker run -d \
  --name ip-geolocation \
  -p 5000:5000 \
  -e MAXMIND_ACCOUNT_ID=your_account_id \
  -e MAXMIND_LICENSE_KEY=your_license_key \
  ip-geolocation-service
```

### Docker Compose Configuration

`docker-compose.yml`:
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - MAXMIND_ACCOUNT_ID=${MAXMIND_ACCOUNT_ID}
      - MAXMIND_LICENSE_KEY=${MAXMIND_LICENSE_KEY}
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/ip_geolocation
    depends_on:
      - db
    volumes:
      - ./data:/app/data
    restart: unless-stopped

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=ip_geolocation
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped

volumes:
  postgres_data:
```

## Cloud Deployment

### Deploy to Railway

1. Fork the repository
2. Connect Railway to your GitHub account
3. Create a new project from your forked repository
4. Add environment variables in Railway dashboard
5. Deploy automatically

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/3YTzGN)

### Deploy to Heroku

```bash
# Install Heroku CLI
# Create Heroku app
heroku create your-ip-geolocation-app

# Set environment variables
heroku config:set MAXMIND_ACCOUNT_ID=your_account_id
heroku config:set MAXMIND_LICENSE_KEY=your_license_key

# Deploy
git push heroku main
```

### Deploy to DigitalOcean App Platform

1. Fork the repository
2. Create new app in DigitalOcean App Platform
3. Connect your GitHub repository
4. Configure environment variables
5. Deploy

### Deploy to AWS EC2

```bash
# Connect to your EC2 instance
ssh -i your-key.pem ubuntu@your-instance-ip

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone and setup
git clone https://github.com/yourusername/ip-geolocation-service.git
cd ip-geolocation-service
npm install
npm run build

# Setup PM2 for process management
sudo npm install -g pm2
pm2 start npm --name "ip-geolocation" -- start
pm2 startup
pm2 save

# Setup Nginx (optional)
sudo apt-get install nginx
# Configure nginx reverse proxy
```

### Deploy to Google Cloud Run

```bash
# Build and push to Google Container Registry
gcloud builds submit --tag gcr.io/PROJECT-ID/ip-geolocation-service

# Deploy to Cloud Run
gcloud run deploy --image gcr.io/PROJECT-ID/ip-geolocation-service --platform managed
```

## Performance Optimization

### 1. Enable Caching

Add Redis for distributed caching:

```bash
npm install redis
```

Update your configuration:

```env
REDIS_URL=redis://localhost:6379
CACHE_ENABLED=true
CACHE_TTL=900
```

### 2. Load Balancing

Use PM2 cluster mode for multiple processes:

```bash
# Start with cluster mode
pm2 start ecosystem.config.js
```

`ecosystem.config.js`:
```javascript
module.exports = {
  apps: [{
    name: 'ip-geolocation',
    script: 'dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};
```

### 3. CDN Configuration

Configure CDN for static assets and API responses:

- Cloudflare
- AWS CloudFront
- Google Cloud CDN

Example Cloudflare configuration:
- Cache Level: Standard
- Browser Cache TTL: 30 minutes
- Edge Cache TTL: 2 hours

## Security Configuration

### 1. Environment Variables

Never commit sensitive data. Use environment variables for:

```env
SESSION_SECRET=generate_random_secret_here
MAXMIND_LICENSE_KEY=your_secret_key
DATABASE_URL=your_database_connection_string
```

### 2. Rate Limiting

Configure rate limiting in your environment:

```env
RATE_LIMIT_WINDOW=60000  # 1 minute window
RATE_LIMIT_MAX=120       # 120 requests per window
TRUST_PROXY=true         # If behind reverse proxy
```

### 3. HTTPS Configuration

Always use HTTPS in production. Configure SSL/TLS:

```nginx
server {
    listen 443 ssl;
    server_name yourdomain.com;
    
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Database Updates

### Automatic Updates

The service automatically updates the MaxMind database monthly. You can also trigger manual updates:

```bash
npm run update-database
```

### Manual Database Placement

Place the MaxMind database file in the `data/` directory:

```
data/
└── GeoLite2-City.mmdb
```

## Monitoring and Logging

### 1. Application Monitoring

Use PM2 for process monitoring:

```bash
pm2 monit
pm2 logs
pm2 show ip-geolocation
```

### 2. Health Checks

The service provides health check endpoints:

- `GET /api/health` - Basic health status
- `GET /api/stats` - Service statistics

### 3. Log Configuration

Configure logging levels:

```env
LOG_LEVEL=info
LOG_FORMAT=json
```

## Troubleshooting

### Common Issues

#### 1. Database Download Fails

```bash
# Check MaxMind credentials
curl -u "ACCOUNT_ID:LICENSE_KEY" \
  "https://download.maxmind.com/app/geoip_download?edition_id=GeoLite2-City&license_key=LICENSE_KEY&suffix=tar.gz"

# Manually download and extract
mkdir -p data
# Place GeoLite2-City.mmdb in data/ directory
```

#### 2. Port Already in Use

```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 PID

# Or use different port
PORT=8080 npm start
```

#### 3. Permission Errors

```bash
# Fix file permissions
chmod +x node_modules/.bin/*
sudo chown -R $USER:$USER .
```

#### 4. Memory Issues

```bash
# Increase Node.js memory limit
NODE_OPTIONS="--max-old-space-size=4096" npm start
```

### Debug Mode

Run in debug mode for detailed logging:

```bash
DEBUG=* npm run dev
```

## Backup and Recovery

### 1. Database Backup

```bash
# Backup MaxMind database
cp data/GeoLite2-City.mmdb backup/GeoLite2-City-$(date +%Y%m%d).mmdb

# Backup PostgreSQL
pg_dump ip_geolocation > backup/database-$(date +%Y%m%d).sql
```

### 2. Configuration Backup

```bash
# Backup configuration
cp .env backup/env-$(date +%Y%m%d).backup
cp ecosystem.config.js backup/ecosystem-$(date +%Y%m%d).backup
```

## Scaling

### Horizontal Scaling

1. Load Balancer (nginx, HAProxy)
2. Multiple application instances
3. Shared cache (Redis)
4. Database clustering

### Vertical Scaling

1. Increase server resources
2. Optimize Node.js memory usage
3. Enable clustering with PM2

## Support

- **Documentation**: Check the [API Documentation](API.md)
- **Issues**: Create an issue on GitHub
- **Community**: Join our discussions

## License

This project is licensed under the MIT License. See [LICENSE](../LICENSE) file for details.