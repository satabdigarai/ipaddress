# API Documentation

Complete reference for the Free IP Geolocation API.

## Base URL
```
https://ip-address.online/api
```

## Authentication
No authentication required. The API is completely free and open.

## Rate Limiting
- **120 requests per minute** per IP address
- Rate limit headers included in response
- Responses cached for 15 minutes

## Common Headers

### Request Headers
```http
Accept: application/json
User-Agent: YourApp/1.0
```

### Response Headers
```http
Content-Type: application/json
X-RateLimit-Limit: 120
X-RateLimit-Remaining: 119
X-RateLimit-Reset: 1640995200
Cache-Control: public, max-age=900
```

## Endpoints

### 1. Get Current IP Location

Get geolocation information for the requesting IP address.

#### Request
```http
GET /api/geo
```

#### Response
```json
{
  "ip": "203.0.113.195",
  "countryCode": "US",
  "country": "United States",
  "regionCode": "CA",
  "region": "California",
  "city": "San Francisco",
  "postalCode": "94102",
  "latitude": 37.7749,
  "longitude": -122.4194,
  "timezone": "America/Los_Angeles",
  "isp": "Example ISP",
  "asn": 12345
}
```

### 2. Get Specific IP Location

Get geolocation information for a specific IP address.

#### Request
```http
GET /api/geo/{ip}
```

#### Parameters
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `ip` | string | Yes | IPv4 or IPv6 address to lookup |

#### Examples
```http
GET /api/geo/8.8.8.8
GET /api/geo/2001:4860:4860::8888
```

#### Response
```json
{
  "ip": "8.8.8.8",
  "countryCode": "US",
  "country": "United States",
  "regionCode": "CA",
  "region": "California",
  "city": "Mountain View",
  "postalCode": "94043",
  "latitude": 37.4056,
  "longitude": -122.0775,
  "timezone": "America/Los_Angeles",
  "isp": "Google LLC",
  "asn": 15169
}
```

### 3. Get Current IP Address

Get only the requesting IP address without location data.

#### Request
```http
GET /api/myip
```

#### Response
```json
{
  "ip": "203.0.113.195"
}
```

### 4. Health Check

Check API service health and database status.

#### Request
```http
GET /api/health
```

#### Response
```json
{
  "ok": true,
  "dbAge": "2d",
  "uptime": 86400
}
```

#### Response Fields
| Field | Type | Description |
|-------|------|-------------|
| `ok` | boolean | Service health status |
| `dbAge` | string | Age of MaxMind database |
| `uptime` | number | Server uptime in seconds |

### 5. Service Statistics

Get API usage statistics and performance metrics.

#### Request
```http
GET /api/stats
```

#### Response
```json
{
  "totalRequests": "1,234,567",
  "avgResponseTime": "<5ms",
  "uptime": "99.9%",
  "cacheHitRate": "85%"
}
```

## Response Fields

### Location Data Fields

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `ip` | string | IP address | `"8.8.8.8"` |
| `countryCode` | string | ISO 3166-1 alpha-2 country code | `"US"` |
| `country` | string | Country name | `"United States"` |
| `regionCode` | string | Region/state code | `"CA"` |
| `region` | string | Region/state name | `"California"` |
| `city` | string | City name | `"Mountain View"` |
| `postalCode` | string | Postal/ZIP code | `"94043"` |
| `latitude` | number | Latitude coordinate | `37.4056` |
| `longitude` | number | Longitude coordinate | `-122.0775` |
| `timezone` | string | IANA timezone identifier | `"America/Los_Angeles"` |
| `isp` | string | Internet Service Provider | `"Google LLC"` |
| `asn` | number | Autonomous System Number | `15169` |

### Nullable Fields
Some fields may be `null` if data is not available:
- `regionCode`
- `region`
- `city` 
- `postalCode`
- `isp`
- `asn`

## Error Handling

### HTTP Status Codes
- `200` - Success
- `400` - Bad Request (invalid IP format)
- `404` - Not Found (endpoint doesn't exist)
- `429` - Too Many Requests (rate limit exceeded)
- `500` - Internal Server Error

### Error Response Format
```json
{
  "error": "Invalid IP address format",
  "code": 400,
  "message": "The provided IP address '999.999.999.999' is not valid"
}
```

### Common Errors

#### Invalid IP Address
```http
GET /api/geo/invalid-ip
```
```json
{
  "error": "Invalid IP address format",
  "code": 400
}
```

#### Rate Limit Exceeded
```json
{
  "error": "Rate limit exceeded",
  "code": 429,
  "message": "You have exceeded the rate limit of 120 requests per minute"
}
```

## CORS Support
The API supports Cross-Origin Resource Sharing (CORS) for browser-based applications.

```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, OPTIONS
Access-Control-Allow-Headers: Content-Type
```

## Security

### HTTPS Only
All API endpoints require HTTPS. HTTP requests will be redirected.

### No Authentication
No API keys or authentication required. The service is completely open.

### Privacy
- No IP addresses are logged or stored
- No user tracking or analytics
- All processing done with offline database

## Performance

### Response Times
- **Average**: < 5ms
- **95th percentile**: < 10ms
- **99th percentile**: < 50ms

### Caching
- Responses cached for 15 minutes
- CDN-friendly cache headers
- High cache hit rate (85%+)

## Code Examples

### cURL
```bash
# Get your location
curl -X GET "https://ip-address.online/api/geo" \
     -H "Accept: application/json"

# Look up specific IP
curl -X GET "https://ip-address.online/api/geo/8.8.8.8" \
     -H "Accept: application/json"
```

### JavaScript Fetch
```javascript
// Get current IP location
const response = await fetch('https://ip-address.online/api/geo');
const data = await response.json();

// Handle errors
if (!response.ok) {
    console.error('API Error:', data.error);
    return;
}

console.log(`Your location: ${data.city}, ${data.country}`);
```

### Error Handling Example
```javascript
async function getIPLocation(ip) {
    try {
        const response = await fetch(`https://ip-address.online/api/geo/${ip}`);
        
        if (response.status === 429) {
            throw new Error('Rate limit exceeded. Please wait before making more requests.');
        }
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(`API Error: ${error.message || error.error}`);
        }
        
        const data = await response.json();
        return data;
        
    } catch (error) {
        console.error('Failed to get IP location:', error.message);
        throw error;
    }
}
```

## Best Practices

### 1. Implement Retry Logic
```javascript
async function getIPLocationWithRetry(ip, maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await getIPLocation(ip);
        } catch (error) {
            if (attempt === maxRetries) throw error;
            if (error.message.includes('Rate limit')) {
                await new Promise(resolve => setTimeout(resolve, 60000)); // Wait 1 minute
            } else {
                await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
            }
        }
    }
}
```

### 2. Cache Responses
```javascript
const locationCache = new Map();

async function getCachedIPLocation(ip) {
    const cacheKey = `location_${ip}`;
    const cached = locationCache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < 900000) { // 15 minutes
        return cached.data;
    }
    
    const data = await getIPLocation(ip);
    locationCache.set(cacheKey, {
        data,
        timestamp: Date.now()
    });
    
    return data;
}
```

### 3. Handle Rate Limits Gracefully
```javascript
function createRateLimitedClient() {
    let lastRequest = 0;
    const minInterval = 500; // 500ms between requests (120/min = 1 per 500ms)
    
    return async function(ip) {
        const now = Date.now();
        const timeSinceLastRequest = now - lastRequest;
        
        if (timeSinceLastRequest < minInterval) {
            await new Promise(resolve => 
                setTimeout(resolve, minInterval - timeSinceLastRequest)
            );
        }
        
        lastRequest = Date.now();
        return await getIPLocation(ip);
    };
}
```

## Webhooks & Bulk Processing
For bulk processing needs (>120 requests/minute), consider:
1. Implementing client-side caching
2. Using batch processing with delays
3. Running your own instance (see [Installation Guide](INSTALLATION.md))

## SDKs and Wrappers
Community-maintained SDKs available for:
- Node.js
- Python
- PHP
- Java
- Go

See our [GitHub repository](https://github.com/yourusername/ip-geolocation-service) for links to SDK projects.